"""Nodo interprete_ordenes — servicio /interpretar_orden (Pregunta 1)."""
import os
import time

import rclpy
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from ordenes_interfaces_g3.srv import InterpretarOrden
from ordenes_g3 import clasificador, laya_cliente


class InterpreteOrdenes(Node):

    def __init__(self):
        super().__init__('interprete_ordenes')
        self.declare_parameter('laya_url', os.environ.get('LAYA_URL', 'http://172.51.1.1:8000'))
        self.declare_parameter('laya_timeout_s', 1.0)
        self.declare_parameter('umbral_permitido', 0.5)
        self.declare_parameter('prioridad_min', 1)
        self.declare_parameter('prioridad_max', 10)
        self.declare_parameter('guardia_prohibidas', True)
        self.declare_parameter('objetos', ['cubo', 'pelota', 'cilindro'])
        # La clave (si existe) solo viene del entorno: nunca va en el código.
        self.clave = os.environ.get('LAYA_API_KEY', '')

        objetos = list(self.get_parameter('objetos').value)
        self.preguntas = laya_cliente.construir_preguntas(objetos)

        self.srv = self.create_service(
            InterpretarOrden, '/interpretar_orden', self.atender,
            callback_group=ReentrantCallbackGroup())
        self.get_logger().info(
            f"interprete_ordenes listo · LAYA={self.get_parameter('laya_url').value} · "
            f"timeout={self.get_parameter('laya_timeout_s').value}s")

    def atender(self, req, res):
        # Los parámetros se leen en cada llamada: se pueden cambiar con `ros2 param set`.
        url = self.get_parameter('laya_url').value
        timeout = float(self.get_parameter('laya_timeout_s').value)
        umbral = float(self.get_parameter('umbral_permitido').value)
        pmin = int(self.get_parameter('prioridad_min').value)
        pmax = int(self.get_parameter('prioridad_max').value)

        frase = req.frase.strip()
        d, motivo, degradada = None, '', False
        rtt = srv_ms = 0.0
        metodo = 'palabras_clave'

        if not frase:
            d = {'accion': 'ninguna', 'objeto': 'cualquiera', 'color': 'ninguno',
                 'nivel': 0.0, 'permitido': False, 'confianza': 0.0}
            motivo = 'orden vacía'
        elif req.forzar_metodo != 'palabras_clave':
            t0 = time.perf_counter()
            try:
                cuerpo, rtt, srv_ms = laya_cliente.consultar(
                    url, self.clave, frase, self.preguntas, timeout)
                d = laya_cliente.parsear(cuerpo, umbral)
                metodo = 'laya'
            except Exception as e:  # timeout, red caída, respuesta inesperada
                rtt = (time.perf_counter() - t0) * 1000.0
                degradada = True
                motivo = f'LAYA no respondió a tiempo ({type(e).__name__}); se usó el respaldo'
                self.get_logger().warn(motivo)

        if d is None:
            d = clasificador.clasificar(frase)
            if req.forzar_metodo == 'palabras_clave':
                motivo = 'método forzado: palabras clave'
            elif not degradada:
                motivo = d['motivo']
            if d['motivo'] and d['motivo'] not in motivo:
                motivo = f"{motivo}; {d['motivo']}".strip('; ')

        # Guardia de seguridad: si la frase contiene una acción prohibida conocida,
        # se rechaza aunque LAYA la haya dado por permitida (defensa en profundidad).
        if (metodo == 'laya' and d['permitido']
                and self.get_parameter('guardia_prohibidas').value
                and clasificador.clasificar(frase)['prohibido']):
            d['permitido'] = False
            motivo = (motivo + '; ' if motivo else '') + 'guardia: la frase contiene una acción prohibida'

        # Una orden que no es acción del brazo nunca es ejecutable.
        if d['accion'] == 'ninguna' and d['permitido']:
            d['permitido'] = False
            motivo = (motivo + '; ' if motivo else '') + 'no es una orden para el brazo'
        if not d['permitido'] and not motivo:
            motivo = (f"rechazada: P(permitido)={d.get('p_permitido', 0.0):.2f} "
                      f"< umbral {umbral:.2f}")

        res.accion = d['accion']
        res.objeto = d['objeto']
        res.color = d['color']
        res.prioridad = clasificador.nivel_a_prioridad(d['nivel'], pmin, pmax)
        res.permitido = bool(d['permitido'])
        res.confianza = float(d['confianza'])
        res.degradada = degradada
        res.metodo = metodo
        res.motivo = motivo
        res.laya_rtt_ms = float(rtt)
        res.laya_servidor_ms = float(srv_ms)
        res.laya_red_ms = max(0.0, float(rtt) - float(srv_ms)) if metodo == 'laya' else 0.0

        self.get_logger().info(
            f"'{frase}' -> {res.accion}/{res.objeto}/{res.color} p={res.prioridad} "
            f"permitido={res.permitido} [{metodo}{' DEGRADADA' if degradada else ''}] "
            f"rtt={rtt:.0f}ms srv={srv_ms:.0f}ms")
        return res


def main(args=None):
    rclpy.init(args=args)
    nodo = InterpreteOrdenes()
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(nodo)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
