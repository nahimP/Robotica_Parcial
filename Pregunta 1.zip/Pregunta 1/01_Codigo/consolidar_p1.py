#!/usr/bin/env python3
"""Consolida las mediciones de la Pregunta 1 en los entregables finales.

Entradas (las genera `medir_p1`, una por escenario):
    resultados_calma.csv            (guardia activada)
    resultados_carga.csv            (guardia activada)
    resultados_calma_laya_puro.csv  (opcional; guardia desactivada = LAYA solo)
y el CSV de las 50 frases con las etiquetas esperadas.

Uso (no necesita ROS; corre en cualquier PC con Python 3):
    python3 consolidar_p1.py --frases frases_50.csv --dir . --salida entrega_p1

Salidas:
    p1_decisiones_50frases.csv   una fila por frase, decisión de cada método
    p1_tablas.md                 latencia (calma/carga) y exactitud
    p1_fallos.md                 frases que falla cada método (para el comentario)
"""
import argparse
import csv
import os

CAMPOS = ['accion', 'objeto', 'color', 'permitido']


def pct(v, p):
    v = sorted(v)
    if not v:
        return float('nan')
    k = (len(v) - 1) * p / 100.0
    f = int(k)
    c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)


def b(x):
    return str(x).strip().lower() in ('1', 'true', 'si', 'sí', 'yes')


def leer(ruta):
    if not os.path.exists(ruta):
        return None
    with open(ruta, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def acierta(obtenido, esperado, campo):
    if campo == 'permitido':
        return b(obtenido) == b(esperado)
    return str(obtenido).strip() == str(esperado).strip()


def categoria(esp):
    if not b(esp['permitido']):
        return 'no permitidas / no son orden'
    return {'recoger': 'recoger', 'inicio': 'inicio', 'detener': 'detener'}.get(esp['accion'], 'otras')


def por_metodo(filas, metodo):
    """frase -> fila, para un método dado (solo respuestas hechas por ese método)."""
    out = {}
    for r in filas or []:
        if r['metodo_pedido'] == metodo and r['metodo_usado'] == metodo:
            out[r['frase']] = r
    return out


def tabla_latencia(filas, titulo):
    ok = [r for r in filas if r['metodo_pedido'] == 'laya' and b(r['degradada']) is False]
    deg = sum(1 for r in filas if r['metodo_pedido'] == 'laya' and b(r['degradada']))
    L = [f'### {titulo}', '', '| Tramo | Mediana (ms) | p95 (ms) |', '|---|---|---|']
    res = {}
    for nombre, k in [('Servicio ROS completo (visto por el cliente)', 'rtt_servicio_ms'),
                      ('HTTP ida y vuelta (nodo -> LAYA -> nodo)', 'laya_rtt_ms'),
                      ('Cálculo en el servidor (informado por LAYA)', 'laya_servidor_ms'),
                      ('Red y sobrecarga (HTTP - servidor)', 'laya_red_ms')]:
        v = [float(r[k]) for r in ok]
        res[k] = (pct(v, 50), pct(v, 95))
        L.append(f'| {nombre} | {res[k][0]:.1f} | {res[k][1]:.1f} |')
    L += ['', f'Muestras válidas de LAYA: {len(ok)} · degradadas por tiempo límite: {deg}', '']
    return L, res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--frases', required=True)
    ap.add_argument('--dir', default='.')
    ap.add_argument('--salida', default='entrega_p1')
    a = ap.parse_args()
    os.makedirs(a.salida, exist_ok=True)

    frases = leer(a.frases)
    calma = leer(os.path.join(a.dir, 'resultados_calma.csv'))
    carga = leer(os.path.join(a.dir, 'resultados_carga.csv'))
    puro = leer(os.path.join(a.dir, 'resultados_calma_laya_puro.csv'))
    if frases is None or calma is None:
        raise SystemExit('Faltan frases o resultados_calma.csv')

    kw = por_metodo(calma, 'palabras_clave')
    laya_g = por_metodo(calma, 'laya')
    laya_p = por_metodo(puro, 'laya') if puro else {}
    fuentes = [('LAYA puro', laya_p), ('LAYA + guardia (sistema final)', laya_g),
               ('Palabras clave', kw)]
    fuentes = [(n, d) for n, d in fuentes if d]

    # ---- CSV ancho: una fila por frase ----
    cols = ['frase'] + [f'esperado_{c}' for c in CAMPOS]
    claves = {'LAYA puro': 'laya_puro', 'LAYA + guardia (sistema final)': 'laya_guardia',
              'Palabras clave': 'kw'}
    for n, _ in fuentes:
        p = claves[n]
        cols += [f'{p}_{c}' for c in CAMPOS] + [f'{p}_prioridad', f'{p}_confianza', f'{p}_ok_completo']
    with open(os.path.join(a.salida, 'p1_decisiones_50frases.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for e in frases:
            fila = {'frase': e['frase']}
            for c in CAMPOS:
                fila[f'esperado_{c}'] = e[c]
            for n, d in fuentes:
                p, r = claves[n], d.get(e['frase'])
                if not r:
                    continue
                for c in CAMPOS:
                    fila[f'{p}_{c}'] = r[c]
                fila[f'{p}_prioridad'] = r['prioridad']
                fila[f'{p}_confianza'] = r['confianza']
                fila[f'{p}_ok_completo'] = all(acierta(r[c], e[c], c) for c in CAMPOS)
            w.writerow(fila)

    # ---- tablas ----
    T = ['# Tablas de la Pregunta 1', '', '## Latencia', '']
    l1, r_calma = tabla_latencia(calma, 'Laboratorio en calma')
    T += l1
    r_carga = None
    if carga:
        l2, r_carga = tabla_latencia(carga, 'Todos los equipos consultando a la vez')
        T += l2
        T += ['### Comparación calma vs. carga', '',
              '| Tramo | Mediana calma | Mediana carga | x | p95 calma | p95 carga | x |', '|---|---|---|---|---|---|---|']
        for k, n in [('rtt_servicio_ms', 'Servicio ROS completo'), ('laya_rtt_ms', 'HTTP ida y vuelta'),
                     ('laya_servidor_ms', 'Cálculo en el servidor'), ('laya_red_ms', 'Red y sobrecarga')]:
            (m1, p1), (m2, p2) = r_calma[k], r_carga[k]
            T.append(f'| {n} | {m1:.1f} | {m2:.1f} | {m2 / m1:.1f} | {p1:.1f} | {p2:.1f} | {p2 / p1:.1f} |')
        T.append('')

    T += ['## Exactitud (50 frases, escenario calma)', '',
          '| Método | acción | objeto | color | permitido | decisión completa |', '|---|---|---|---|---|---|']
    stats_cat = {}
    for n, d in fuentes:
        aciertos = {c: 0 for c in CAMPOS}
        comp = tot = 0
        for e in frases:
            r = d.get(e['frase'])
            if not r:
                continue
            tot += 1
            oks = {c: acierta(r[c], e[c], c) for c in CAMPOS}
            for c in CAMPOS:
                aciertos[c] += oks[c]
            todo = all(oks.values())
            comp += todo
            cat = categoria(e)
            s = stats_cat.setdefault(cat, {}).setdefault(n, [0, 0])
            s[0] += todo
            s[1] += 1
        if tot:
            T.append(f'| {n} | ' + ' | '.join(f'{100 * aciertos[c] / tot:.0f}%' for c in CAMPOS)
                     + f' | {100 * comp / tot:.0f}% ({comp}/{tot}) |')
    T += ['', '### Decisión completa por tipo de frase', '',
          '| Tipo de frase | ' + ' | '.join(n for n, _ in fuentes) + ' |', '|---|' + '---|' * len(fuentes)]
    for cat, dd in stats_cat.items():
        T.append(f'| {cat} | ' + ' | '.join(
            f'{100 * dd[n][0] / dd[n][1]:.0f}% ({dd[n][0]}/{dd[n][1]})' if n in dd else '-' for n, _ in fuentes) + ' |')
    with open(os.path.join(a.salida, 'p1_tablas.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(T) + '\n')

    # ---- fallos ----
    F = ['# Frases que falla cada método', '']
    for n, d in fuentes:
        F += [f'## {n}', '', '| Frase | Esperado | Obtenido |', '|---|---|---|']
        nfall = 0
        for e in frases:
            r = d.get(e['frase'])
            if not r:
                continue
            mal = [c for c in CAMPOS if not acierta(r[c], e[c], c)]
            if mal:
                nfall += 1
                exp = ', '.join(f'{c}={e[c]}' for c in mal)
                obt = ', '.join(f'{c}={r[c]}' for c in mal)
                F.append(f'| {e["frase"]} | {exp} | {obt} |')
        F += ['', f'Total con al menos un error: {nfall}', '']
    with open(os.path.join(a.salida, 'p1_fallos.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(F) + '\n')
    print(f'Listo. Archivos en: {a.salida}/')
    print('\n'.join(T))


if __name__ == '__main__':
    main()
