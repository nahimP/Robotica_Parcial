"""Medición de la Pregunta 1: latencia y exactitud de /interpretar_orden.

Uso:
    ros2 run ordenes_g3 medir_p1 --frases frases.csv --escenario calma
    ros2 run ordenes_g3 medir_p1 --frases frases.csv --escenario carga

CSV de entrada: columna `frase` (obligatoria) y, opcionales, las etiquetas
esperadas `accion,objeto,color,permitido`. Solo se evalúan las columnas presentes.

ANTES de medir, escribe tu predicción (mediana, p95, exactitud) en tu informe.
Cada frase se consulta con LAYA y con el clasificador de palabras clave.
"""
import argparse
import csv
import os
import time

import rclpy

from ordenes_interfaces_g3.srv import InterpretarOrden

CAMPOS = ['accion', 'objeto', 'color', 'permitido']


def pct(valores, p):
    v = sorted(valores)
    if not v:
        return float('nan')
    k = (len(v) - 1) * p / 100.0
    f = int(k)
    c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)


def a_bool(x):
    return str(x).strip().lower() in ('1', 'true', 'si', 'sí', 'yes')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--frases', required=True)
    ap.add_argument('--escenario', default='calma')
    ap.add_argument('--salida', default='.')
    ap.add_argument('--timeout', type=float, default=30.0)
    args, _ = ap.parse_known_args()

    with open(args.frases, newline='', encoding='utf-8') as f:
        filas = list(csv.DictReader(f))
    esperados = [c for c in CAMPOS if filas and c in filas[0]]

    rclpy.init()
    nodo = rclpy.create_node('medir_p1')
    cli = nodo.create_client(InterpretarOrden, '/interpretar_orden')
    if not cli.wait_for_service(timeout_sec=10.0):
        raise SystemExit('No existe /interpretar_orden: ¿está corriendo interprete_ordenes?')

    resultados = []
    for i, fila in enumerate(filas, 1):
        for metodo in ('laya', 'palabras_clave'):
            req = InterpretarOrden.Request()
            req.frase = fila['frase']
            req.forzar_metodo = metodo
            t0 = time.perf_counter()
            fut = cli.call_async(req)
            rclpy.spin_until_future_complete(nodo, fut, timeout_sec=args.timeout)
            rtt = (time.perf_counter() - t0) * 1000.0
            if not fut.done():
                print(f'[{i}] sin respuesta del servicio ({metodo})')
                continue
            r = fut.result()
            reg = {
                'frase': fila['frase'], 'metodo_pedido': metodo, 'metodo_usado': r.metodo,
                'degradada': r.degradada, 'accion': r.accion, 'objeto': r.objeto,
                'color': r.color, 'prioridad': r.prioridad, 'permitido': r.permitido,
                'confianza': round(r.confianza, 4), 'rtt_servicio_ms': round(rtt, 2),
                'laya_rtt_ms': round(r.laya_rtt_ms, 2),
                'laya_servidor_ms': round(r.laya_servidor_ms, 2),
                'laya_red_ms': round(r.laya_red_ms, 2),
            }
            for c in esperados:
                ok = (str(r.permitido).lower() == str(a_bool(fila[c])).lower()
                      if c == 'permitido' else str(getattr(r, c)) == fila[c].strip())
                reg[f'ok_{c}'] = ok
            resultados.append(reg)
        print(f'{i}/{len(filas)} {fila["frase"][:50]}')

    os.makedirs(args.salida, exist_ok=True)
    ruta_csv = os.path.join(args.salida, f'resultados_{args.escenario}.csv')
    if resultados:
        with open(ruta_csv, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(resultados[0].keys()))
            w.writeheader()
            w.writerows(resultados)

    lineas = [f'# Resumen P1 — escenario: {args.escenario}', '',
              '## Latencia (solo respuestas de LAYA, ms)', '',
              '| Métrica | Mediana | p95 |', '|---|---|---|']
    laya_ok = [r for r in resultados if r['metodo_pedido'] == 'laya' and not r['degradada']]
    for nombre, clave in [('Servicio ROS completo (cliente)', 'rtt_servicio_ms'),
                          ('HTTP ida y vuelta', 'laya_rtt_ms'),
                          ('Cálculo en el servidor', 'laya_servidor_ms'),
                          ('Red y sobrecarga', 'laya_red_ms')]:
        v = [r[clave] for r in laya_ok]
        lineas.append(f'| {nombre} | {pct(v, 50):.1f} | {pct(v, 95):.1f} |')
    n_deg = sum(1 for r in resultados if r['metodo_pedido'] == 'laya' and r['degradada'])
    lineas += ['', f'Muestras LAYA válidas: {len(laya_ok)} · degradadas (timeout): {n_deg}', '']

    if esperados:
        lineas += ['## Exactitud', '', '| Método | ' + ' | '.join(esperados) + ' | decisión completa |',
                   '|---|' + '---|' * (len(esperados) + 1)]
        for m in ('laya', 'palabras_clave'):
            rs = [r for r in resultados if r['metodo_pedido'] == m and r['metodo_usado'] == m]
            if not rs:
                continue
            cols = [f"{100 * sum(r[f'ok_{c}'] for r in rs) / len(rs):.0f}%" for c in esperados]
            comp = 100 * sum(all(r[f'ok_{c}'] for c in esperados) for r in rs) / len(rs)
            lineas.append(f'| {m} | ' + ' | '.join(cols) + f' | {comp:.0f}% |')
    texto = '\n'.join(lineas)
    with open(os.path.join(args.salida, f'resumen_{args.escenario}.md'), 'w', encoding='utf-8') as f:
        f.write(texto)
    print('\n' + texto + f'\n\nGuardado: {ruta_csv}')
    nodo.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
