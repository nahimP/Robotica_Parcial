"""Cliente HTTP mínimo para el servidor LAYA (/v1/systemone).

Solo librería estándar. El plazo es TOTAL (no por operación de socket): si LAYA
no responde dentro de `timeout_s`, se lanza excepción y el nodo usa el respaldo.
"""
import json
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

_POOL = ThreadPoolExecutor(max_workers=16)

ACCIONES = {
    'recoger': 'tomar, agarrar, levantar, traer o llevar un objeto de un lugar a otro',
    'inicio': 'volver el brazo a su posición de reposo, sin pedir mover ningún objeto',
    'detener': 'parar o detener el brazo de inmediato',
    'ninguna': 'cualquier otra cosa: saludar, conversar, o pedir tirar, lanzar, golpear o romper algo',
}
COLORES = {
    'rojo': 'el objeto rojo', 'azul': 'el objeto azul',
    'verde': 'el objeto verde', 'amarillo': 'el objeto amarillo',
    'ninguno': 'no se menciona ningún color',
}


def construir_preguntas(objetos):
    crit_obj = {o: f'el objeto llamado {o}' for o in objetos}
    crit_obj['cualquiera'] = 'no se nombra un tipo de objeto concreto'
    return {
        'accion': {'type': 'choice',
                   'instructions': '¿Qué acción pide la orden?',
                   'criteria': ACCIONES},
        'objeto': {'type': 'choice',
                   'instructions': '¿Qué tipo de objeto menciona la orden?',
                   'criteria': crit_obj},
        'color': {'type': 'choice',
                  'instructions': '¿Qué color de objeto menciona la orden?',
                  'criteria': COLORES},
        'urgencia': {'type': 'score',
                     'instructions': '¿Qué tan urgente es la orden?',
                     'criteria': ['normal', 'importante', 'urgente']},
        'permitido': {'type': 'noul',
                      'instructions': '¿La orden pide únicamente recoger y mover un objeto de la '
                                      'mesa con cuidado, sin tirarlo, lanzarlo, golpearlo ni '
                                      'dañar nada ni a nadie?'},
    }


def consultar(url, clave, frase, preguntas, timeout_s):
    """Devuelve (cuerpo_json, rtt_ms, servidor_ms). Lanza excepción si falla."""
    def _post():
        cab = {'Content-Type': 'application/json'}
        if clave:
            cab['Authorization'] = f'Bearer {clave}'
        datos = json.dumps({'state': {'body': frase}, 'questions': preguntas}).encode()
        req = urllib.request.Request(url.rstrip('/') + '/v1/systemone',
                                     data=datos, headers=cab, method='POST')
        t0 = time.perf_counter()
        with urllib.request.urlopen(req, timeout=timeout_s + 1.0) as r:
            cuerpo = json.loads(r.read().decode())
            srv = float(r.headers.get('x-inference-time-ms') or 0.0)
        return cuerpo, (time.perf_counter() - t0) * 1000.0, srv

    return _POOL.submit(_post).result(timeout=timeout_s)


def parsear(cuerpo, umbral_permitido):
    r = cuerpo['answers']
    choices = [r[k] for k in ('accion', 'objeto', 'color')]
    p_perm = float(r['permitido']['noul'])
    return {
        'accion': r['accion']['choice'],
        'objeto': r['objeto']['choice'],
        'color': r['color']['choice'],
        'nivel': float(r['urgencia']['score']),
        'permitido': p_perm >= umbral_permitido,
        'p_permitido': p_perm,
        'confianza': min(float(c['answer_confidence']) for c in choices),
    }
