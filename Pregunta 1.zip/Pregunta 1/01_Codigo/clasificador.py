"""Clasificador por palabras clave: respaldo cuando LAYA no responde a tiempo.

Regla de seguridad: por defecto se DENIEGA. Una orden solo es 'permitida' si se
reconoce una acción válida y no aparece ningún término prohibido.
"""
import re
import unicodedata

ACCIONES_PERMITIDAS = {'recoger', 'inicio', 'detener'}

_COLORES = [('rojo', ('roj',)), ('azul', ('azul',)),
            ('verde', ('verd',)), ('amarillo', ('amarill',))]
_OBJETOS = [('cubo', ('cub',)), ('pelota', ('pelota', 'esfera', 'bola')),
            ('cilindro', ('cilindr',))]

_RECOGER_PREF = ('recog', 'toma', 'agarr', 'coge', 'cog', 'levant', 'trae',
                 'traig', 'llev', 'mueve', 'mover', 'pasa', 'deposit',
                 'coloca', 'ubica', 'guarda', 'alcanz')
_RECOGER_EXACTO = {'pon', 'ponlo', 'ponla', 'poner'}
_INICIO_PREF = ('inicio', 'home', 'reposo', 'vuelve', 'volver', 'regresa',
                'regresar', 'descansa')
_DETENER_PREF = ('deten', 'frena')
_DETENER_EXACTO = {'alto', 'stop', 'pare', 'parate'}

_URGENTE_PREF = ('urgen', 'inmediat', 'emergenc', 'rapid')
_URGENTE_EXACTO = {'ya', 'ahora'}
_IMPORTANTE_PREF = ('import', 'prioridad', 'pronto')

_PROHIBIDO_PREF = ('tir', 'lanz', 'romp', 'golpe', 'destru', 'aplast', 'quem',
                   'ignor', 'ataca', 'dana', 'agred', 'lastim')
_PROHIBIDO_FRASES = ('al suelo', 'fuera de la mesa', 'a la persona',
                     'a una persona', 'a la gente', 'sin cuidado',
                     'deja caer', 'no recoj')


def normalizar(texto):
    t = unicodedata.normalize('NFD', texto.lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', ' ', t)


def nivel_a_prioridad(nivel, pmin, pmax):
    """Nivel 0..2 (normal..urgente) -> entero pmin..pmax. MAYOR = más urgente."""
    nivel = max(0.0, min(2.0, float(nivel)))
    return int(round(pmin + (pmax - pmin) * nivel / 2.0))


def _alguno(tokens, prefijos=(), exactos=()):
    return any(t.startswith(prefijos) or t in exactos for t in tokens) if (prefijos or exactos) else False


def clasificar(frase):
    norm = normalizar(frase)
    tokens = norm.split()

    if _alguno(tokens, _DETENER_PREF, _DETENER_EXACTO) or (tokens and tokens[0] == 'para'):
        accion = 'detener'
    elif _alguno(tokens, _RECOGER_PREF, _RECOGER_EXACTO):
        accion = 'recoger'
    elif _alguno(tokens, _INICIO_PREF):
        accion = 'inicio'
    else:
        accion = 'ninguna'

    def primero(tabla, defecto):
        mejor, pos = defecto, None
        for nombre, prefs in tabla:
            for i, t in enumerate(tokens):
                if t.startswith(prefs) and (pos is None or i < pos):
                    mejor, pos = nombre, i
                    break
        return mejor

    color = primero(_COLORES, 'ninguno')
    objeto = primero(_OBJETOS, 'cualquiera')

    if _alguno(tokens, _URGENTE_PREF, _URGENTE_EXACTO) or 'cuanto antes' in norm:
        nivel = 2.0
    elif _alguno(tokens, _IMPORTANTE_PREF):
        nivel = 1.0
    else:
        nivel = 0.0

    prohibido = _alguno(tokens, _PROHIBIDO_PREF) or any(f in norm for f in _PROHIBIDO_FRASES)
    permitido = accion in ACCIONES_PERMITIDAS and not prohibido
    if prohibido:
        motivo = 'contiene un término de acción prohibida'
    elif accion == 'ninguna':
        motivo = 'no se reconoce una acción válida para el brazo'
    else:
        motivo = ''

    return {'accion': accion, 'objeto': objeto, 'color': color, 'nivel': nivel,
            'permitido': permitido, 'prohibido': prohibido,
            'confianza': 0.6 if accion != 'ninguna' else 0.2,
            'motivo': motivo}
