# Tablas de la Pregunta 1

## Latencia

### Laboratorio en calma

| Tramo | Mediana (ms) | p95 (ms) |
|---|---|---|
| Servicio ROS completo (visto por el cliente) | 127.1 | 167.4 |
| HTTP ida y vuelta (nodo -> LAYA -> nodo) | 121.7 | 161.7 |
| Cálculo en el servidor (informado por LAYA) | 107.0 | 142.8 |
| Red y sobrecarga (HTTP - servidor) | 12.3 | 21.0 |

Muestras válidas de LAYA: 50 · degradadas por tiempo límite: 0

### Todos los equipos consultando a la vez

| Tramo | Mediana (ms) | p95 (ms) |
|---|---|---|
| Servicio ROS completo (visto por el cliente) | 913.4 | 975.7 |
| HTTP ida y vuelta (nodo -> LAYA -> nodo) | 906.9 | 967.3 |
| Cálculo en el servidor (informado por LAYA) | 144.5 | 195.1 |
| Red y sobrecarga (HTTP - servidor) | 755.8 | 805.0 |

Muestras válidas de LAYA: 48 · degradadas por tiempo límite: 2

### Comparación calma vs. carga

| Tramo | Mediana calma | Mediana carga | x | p95 calma | p95 carga | x |
|---|---|---|---|---|---|---|
| Servicio ROS completo | 127.1 | 913.4 | 7.2 | 167.4 | 975.7 | 5.8 |
| HTTP ida y vuelta | 121.7 | 906.9 | 7.5 | 161.7 | 967.3 | 6.0 |
| Cálculo en el servidor | 107.0 | 144.5 | 1.4 | 142.8 | 195.1 | 1.4 |
| Red y sobrecarga | 12.3 | 755.8 | 61.6 | 21.0 | 805.0 | 38.4 |

## Exactitud (50 frases, escenario calma)

| Método | acción | objeto | color | permitido | decisión completa |
|---|---|---|---|---|---|
| LAYA puro | 64% | 90% | 100% | 48% | 38% (19/50) |
| LAYA + guardia (sistema final) | 64% | 90% | 100% | 64% | 38% (19/50) |
| Palabras clave | 88% | 100% | 100% | 90% | 88% (44/50) |

### Decisión completa por tipo de frase

| Tipo de frase | LAYA puro | LAYA + guardia (sistema final) | Palabras clave |
|---|---|---|---|
| recoger | 50% (14/28) | 50% (14/28) | 82% (23/28) |
| inicio | 20% (1/5) | 20% (1/5) | 100% (5/5) |
| detener | 25% (1/4) | 25% (1/4) | 100% (4/4) |
| no permitidas / no son orden | 23% (3/13) | 23% (3/13) | 92% (12/13) |
