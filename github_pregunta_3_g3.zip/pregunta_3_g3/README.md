# Pregunta 3 — Grupo 3: de la voz al movimiento

Nodo `transcriptor_voz`: audio del micrófono → Google AI Studio (transcripción en español) →
`/interpretar_orden` → cola del broker → brazo. Si no hay internet o la nube tarda más de 10 s,
avisa «MODO TEXTO» y se escribe la orden a mano. El nodo no publica comandos al brazo.

## Carpetas
- `codigo/transcriptor_voz_g3.py` — nodo (Jetson). `codigo/decision_g3.py` — validación de la decisión (misma de la pregunta 2).
- `codigo/grabar_pc_g3.py` — grabador para la PC del laboratorio (micrófono Logitech Brio 100).
- `codigo/probar_gemini_g3.py`, `codigo/probar_transcripcion_g3.py` — comprobación de la clave y comparación de modelos.
- `resultados/audios_g3/` — 25 audios `.wav`, cada uno con su `.txt` (transcripción, modelo, estado).
- `resultados/voz_pedidos_g3.csv` — un pedido por fila con el tiempo de cada etapa.
- `resultados/fig_desglose_tiempos_g3.png` — figura del desglose de tiempos.

## Seguridad
La clave **no está en este repositorio**. Se lee de la variable de entorno `GOOGLE_API_KEY`:
```bash
read -rs GOOGLE_API_KEY      # pegar la clave (no se ve) y Enter
export GOOGLE_API_KEY
```

## Cómo se ejecuta
Jetson (con driver, move_group, broker e intérprete corriendo; mismo entorno ROS que la pregunta 2):
```bash
cd ~/orq_g3 && python3 transcriptor_voz_g3.py
```
PC del laboratorio (cmd): `pip install sounddevice` y luego
`python grabar_pc_g3.py --dispositivo 1 --jetson 172.51.1.20` (Enter empieza y Enter termina la grabación).
Broker usado en las pruebas por voz: `-p tau_envejecimiento_s:=60.0`.
Demostración sin internet: se borra la ruta por defecto de la Jetson (`sudo ip route del default via 172.51.0.1 dev wlP1p1s0`); el video se entrega aparte.
