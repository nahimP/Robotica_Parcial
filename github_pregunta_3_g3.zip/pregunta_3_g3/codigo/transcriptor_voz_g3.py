#!/usr/bin/env python3
"""transcriptor_voz_g3 — nodo `transcriptor_voz` (Pregunta 3, grupo 3). Corre en el Jetson.

Antepone una etapa a lo ya construido:
    audio -> Google AI Studio (transcripción) -> /interpretar_orden (P1) -> validación
          -> cola del broker (/pick_place_g3, prioridad = la del modelo) -> brazo.
Este nodo NUNCA publica comandos al brazo; solo se SUSCRIBE a /arm_g3/joint_command para
medir cuándo empieza a moverse.

Entradas de audio (cualquiera):
  * la computadora del laboratorio (grabar_pc_g3.py) manda el WAV por HTTP a este nodo;
  * un archivo:   python3 transcriptor_voz_g3.py --archivo orden.wav --cliente ana
Entrada de texto (modo de respaldo): escribir la orden en esta terminal y pulsar Enter, o
desde la computadora del laboratorio (el grabador pasa solo a pedir texto si hay fallback).

Seguridad y robustez:
  * La clave se lee de la variable de entorno GOOGLE_API_KEY. Nunca está en el código.
  * Tiempo límite PROPIO (--limite, 10 s por defecto) para toda la transcripción. Si vence, si
    no hay internet o falta la clave, el nodo avisa "MODO TEXTO" y no manda nada al brazo.
  * Cada audio queda guardado junto a su transcripción (carpeta audios_g3/).
  * Cada pedido deja una fila con los tiempos de cada etapa en voz_pedidos_g3.csv.
"""
import argparse
import base64
import csv
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import rclpy
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState

from ordenes_interfaces_g3.srv import InterpretarOrden
from arm_broker_interfaces_g3.action import PickPlace

from decision_g3 import validar_decision

GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta'
MODELOS = ['gemini-3-flash-preview', 'gemini-flash-latest', 'gemini-3.1-flash-lite']
PROMPT = ('Transcribe literalmente, en español, lo que dice la persona en este audio. '
          'Responde SOLO con el texto transcrito, sin comillas ni comentarios. '
          'Si no hay voz inteligible responde exactamente: [SIN_VOZ]')
MIMES = {'.wav': 'audio/wav', '.mp3': 'audio/mp3', '.ogg': 'audio/ogg', '.flac': 'audio/flac',
         '.aac': 'audio/aac', '.aiff': 'audio/aiff', '.m4a': 'audio/aac'}

CAMPOS = ['t_epoch', 'cliente', 'origen', 'audio', 'dur_audio_s', 'transcripcion', 'modelo',
          'intentos', 'estado', 'causa', 'accion', 'objeto', 'color', 'prioridad', 'permitido',
          'metodo', 'degradada',
          't_cierre_pc_s', 't_subida_s', 't_captura_s', 't_transcripcion_s', 't_decision_s',
          't_cola_s', 't_percepcion_s', 't_ik_s', 't_plan_s', 't_hasta_primer_cmd_s',
          't_voz_a_movimiento_s', 't_suma_etapas_s', 'success', 'ejec_s', 'error_pos_mm', 'mensaje']

RE_TIEMPOS = re.compile(r'percepción ([\d.]+) s · IK (\d+) cálculos ([\d.]+) ms · '
                        r'MoveIt2 (\d+) planes ([\d.]+) s')


# ----------------------------------------------------------------------------- transcripción
class ErrorTranscripcion(Exception):
    """La transcripción no se pudo obtener: el sistema pasa a modo texto."""


def _con_limite(fn, limite_s):
    """Ejecuta fn() en un hilo y espera como máximo limite_s. -> ('ok', v) | ('error', e) | ('tiempo', None)."""
    caja = {}

    def corre():
        try:
            caja['v'] = fn()
        except Exception as e:                       # noqa: BLE001
            caja['e'] = e
    h = threading.Thread(target=corre, daemon=True)
    h.start()
    h.join(max(0.0, limite_s))
    if h.is_alive():
        return 'tiempo', None
    return ('error', caja['e']) if 'e' in caja else ('ok', caja.get('v'))


def _llamar(url_base, modelo, cuerpo, clave, timeout_s):
    req = urllib.request.Request(
        f'{url_base}/models/{modelo}:generateContent', data=cuerpo,
        headers={'x-goog-api-key': clave, 'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout_s) as r:
        return json.loads(r.read().decode('utf-8'))


def _texto_de(resp):
    partes = resp['candidates'][0]['content']['parts']
    t = ''.join(p.get('text', '') for p in partes if not p.get('thought')).strip()
    t = t.strip('"\'`« »').strip()
    return re.sub(r'\s+', ' ', t)


def transcribir(audio, mime, modelos, limite_s, clave, url_base=GEMINI_URL, sin_internet=False):
    """Transcribe `audio` (bytes). Devuelve {'texto','modelo','intentos','t_s'} o lanza
    ErrorTranscripcion(causa). Todo el proceso respeta `limite_s` (tiempo límite propio)."""
    t0 = time.perf_counter()
    if not clave:
        raise ErrorTranscripcion('no hay clave: falta la variable de entorno GOOGLE_API_KEY')
    if sin_internet:
        raise ErrorTranscripcion('sin internet (simulado con --simular-sin-internet)')
    cuerpo = json.dumps({
        'contents': [{'parts': [{'text': PROMPT},
                                {'inline_data': {'mime_type': mime,
                                                 'data': base64.b64encode(audio).decode('ascii')}}]}],
        'generationConfig': {'temperature': 0}}).encode('utf-8')
    traza, intentos = [], 0
    tope = max(2.5, limite_s / 2.0)          # un modelo colgado no consume todo el plazo
    for modelo in modelos:
        restante = limite_s - (time.perf_counter() - t0)
        if restante < 0.8:
            break
        intentos += 1
        espera = min(restante, tope) if modelo != modelos[-1] else restante
        estado, valor = _con_limite(lambda m=modelo, r=espera: _llamar(url_base, m, cuerpo, clave, r),
                                    espera)
        if estado == 'tiempo':
            traza.append(f'{modelo}: sin respuesta en {espera:.0f} s')
            continue
        if estado == 'error':
            e = valor
            if isinstance(e, urllib.error.HTTPError):
                traza.append(f'{modelo}: HTTP {e.code}')
                continue                              # 404/429/503: se prueba el siguiente modelo
            if isinstance(e, (urllib.error.URLError, ConnectionError, OSError)) and not isinstance(e, TimeoutError):
                raise ErrorTranscripcion(f'sin conexión a internet ({type(e).__name__})')
            traza.append(f'{modelo}: {type(e).__name__}')
            continue
        try:
            texto = _texto_de(valor)
        except (KeyError, IndexError, TypeError):
            traza.append(f'{modelo}: respuesta sin texto')
            continue
        return {'texto': '' if 'SIN_VOZ' in texto.upper() else texto, 'modelo': modelo,
                'intentos': intentos, 't_s': time.perf_counter() - t0}
    raise ErrorTranscripcion(f'no hubo transcripción en {limite_s:g} s ({"; ".join(traza) or "sin intentos"})')


# ----------------------------------------------------------------------------- el nodo
class TranscriptorVoz(Node):

    def __init__(self, cfg):
        super().__init__('transcriptor_voz')
        self.cfg = cfg
        self.clave = os.environ.get('GOOGLE_API_KEY', '')
        self.interprete = self.create_client(InterpretarOrden, '/interpretar_orden')
        self.broker = ActionClient(self, PickPlace, '/pick_place_g3')
        self.cmds = deque(maxlen=5000)       # instantes (epoch) en que el worker publicó un comando
        self.create_subscription(JointState, '/arm_g3/joint_command',
                                 lambda _m: self.cmds.append(time.time()), 10)
        self.lock = threading.Lock()
        self.hilos = []
        self.modo_texto = False
        os.makedirs(cfg.audios, exist_ok=True)

    # ---- utilidades
    @staticmethod
    def _esperar(future, timeout):
        ev = threading.Event()
        future.add_done_callback(lambda _: ev.set())
        return ev.wait(timeout) and future.done()

    def _avisar_modo_texto(self, causa):
        self.modo_texto = True
        print('\n' + '=' * 70, flush=True)
        print(f'MODO TEXTO: no se pudo transcribir el audio ({causa}).', flush=True)
        print('El brazo NO recibe nada. Escribe la orden aquí (y Enter) o en la PC del laboratorio.',
              flush=True)
        print('=' * 70, flush=True)

    def _guardar_audio(self, cliente, audio, mime):
        ext = {v: k for k, v in MIMES.items()}.get(mime, '.wav')
        base = os.path.join(self.cfg.audios, f'{datetime.now():%Y%m%d_%H%M%S_%f}_{cliente}')
        with open(base + ext, 'wb') as f:
            f.write(audio)
        return base + ext

    @staticmethod
    def _guardar_texto(ruta_audio, ctx):
        if not ruta_audio:
            return
        with open(os.path.splitext(ruta_audio)[0] + '.txt', 'w', encoding='utf-8') as f:
            f.write(f"audio: {os.path.basename(ruta_audio)}\n"
                    f"cliente: {ctx['cliente']}\n"
                    f"transcripcion: {ctx.get('transcripcion', '')}\n"
                    f"modelo: {ctx.get('modelo', '')}\n"
                    f"estado_transcripcion: {ctx.get('estado_transcripcion', '')}\n")

    def _registrar(self, ctx):
        ctx['t_epoch'] = round(ctx.get('t_epoch', time.time()), 3)
        t = ctx
        partes = [t.get(k) for k in ('t_captura_s', 't_transcripcion_s', 't_decision_s',
                                     't_cola_s', 't_percepcion_s', 't_ik_s', 't_plan_s')]
        if any(isinstance(p, (int, float)) for p in partes):
            t['t_suma_etapas_s'] = round(sum(p for p in partes if isinstance(p, (int, float))), 3)
        with self.lock:
            nuevo = not os.path.exists(self.cfg.registro) or os.path.getsize(self.cfg.registro) == 0
            with open(self.cfg.registro, 'a', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=CAMPOS)
                if nuevo:
                    w.writeheader()
                w.writerow({k: (round(v, 3) if isinstance(v, float) else v)
                            for k, v in ((k, ctx.get(k, '')) for k in CAMPOS)})
        print(f"[{ctx['cliente']}] {ctx['estado']} · \"{ctx.get('transcripcion', '')}\" · "
              f"{ctx.get('causa', '')}", flush=True)

    # ---- flujo principal
    def procesar(self, cliente, audio=None, mime='audio/wav', frase=None, meta=None):
        """Voz o texto -> decisión -> cola. Devuelve un dict para el cliente (rápido: no espera
        a que el brazo termine). El resultado final se registra en un hilo aparte."""
        meta = meta or {}
        ctx = {'cliente': cliente, 't_epoch': time.time(), 'origen': 'voz' if audio is not None else 'texto',
               'dur_audio_s': meta.get('dur_audio_s', ''),
               't_cierre_pc_s': meta.get('cierre_pc_s', ''), 't_subida_s': meta.get('subida_s', '')}
        if isinstance(ctx['t_cierre_pc_s'], (int, float)) and isinstance(ctx['t_subida_s'], (int, float)):
            ctx['t_captura_s'] = ctx['t_cierre_pc_s'] + ctx['t_subida_s']
        t_audio_listo = time.time()
        ctx['_t0'] = t_audio_listo

        if audio is not None:
            ctx['audio'] = self._guardar_audio(cliente, audio, mime)
            t0 = time.perf_counter()
            try:
                tr = transcribir(audio, mime, self.cfg.modelos, self.cfg.limite, self.clave,
                                 self.cfg.gemini_url, self.cfg.simular_sin_internet)
            except ErrorTranscripcion as e:
                ctx.update(t_transcripcion_s=time.perf_counter() - t0, estado='MODO_TEXTO',
                           causa=str(e), estado_transcripcion=f'FALLÓ: {e}')
                self._guardar_texto(ctx['audio'], ctx)
                self._avisar_modo_texto(str(e))
                self._registrar(ctx)
                return self._resp(ctx)
            self.modo_texto = False
            frase = tr['texto']
            ctx.update(transcripcion=frase, modelo=tr['modelo'], intentos=tr['intentos'],
                       t_transcripcion_s=tr['t_s'], estado_transcripcion='OK')
            self._guardar_texto(ctx['audio'], ctx)
            if not frase:
                ctx.update(estado='SIN_VOZ', causa='no se detectó voz inteligible; repite la orden')
                self._registrar(ctx)
                return self._resp(ctx)
        else:
            ctx['transcripcion'] = frase

        # --- decisión del modelo (/interpretar_orden de la P1)
        if not self.interprete.wait_for_service(timeout_sec=5.0):
            ctx.update(estado='ERROR', causa='intérprete no disponible')
            self._registrar(ctx)
            return self._resp(ctx)
        req = InterpretarOrden.Request()
        req.frase, req.forzar_metodo = frase, ''
        t0 = time.perf_counter()
        fut = self.interprete.call_async(req)
        if not self._esperar(fut, 15.0) or fut.exception():
            ctx.update(estado='ERROR', causa='el intérprete no respondió', t_decision_s=time.perf_counter() - t0)
            self._registrar(ctx)
            return self._resp(ctx)
        d = fut.result()
        ctx['t_decision_s'] = time.perf_counter() - t0
        ctx.update(accion=d.accion, objeto=d.objeto, color=d.color, prioridad=d.prioridad,
                   permitido=d.permitido, metodo=d.metodo, degradada=d.degradada)
        ok, causa, objeto = validar_decision(d)
        if not ok:                                   # rechazo ANTES de encolar, con su causa
            ctx.update(estado='RECHAZADA_ANTES_DE_COLA', causa=causa)
            self._registrar(ctx)
            return self._resp(ctx)

        # --- cola del broker
        if not self.broker.wait_for_server(timeout_sec=5.0):
            ctx.update(estado='ERROR', causa='broker no disponible')
            self._registrar(ctx)
            return self._resp(ctx)
        goal = PickPlace.Goal()
        goal.client_id, goal.accion, goal.objeto, goal.color = cliente, d.accion, objeto, d.color
        goal.priority = int(d.prioridad)             # prioridad = la del modelo
        fut = self.broker.send_goal_async(goal)
        if not self._esperar(fut, 10.0):
            ctx.update(estado='ERROR', causa='el broker no respondió al pedido')
            self._registrar(ctx)
            return self._resp(ctx)
        handle = fut.result()
        if not handle.accepted:
            ctx.update(estado='RECHAZADA_POR_BROKER', causa='el broker rechazó el pedido (cola llena o solicitud inválida)')
            self._registrar(ctx)
            return self._resp(ctx)
        ctx.update(estado='ENCOLADA', causa=f'prioridad {goal.priority}', _t_enc=time.time())
        h = threading.Thread(target=self._completar, args=(handle, ctx), daemon=True)
        h.start()
        self.hilos.append(h)
        print(f"[{cliente}] ENCOLADA · \"{frase}\" · prioridad {goal.priority}", flush=True)
        return self._resp(ctx)

    def _completar(self, handle, ctx):
        res_fut = handle.get_result_async()
        if not self._esperar(res_fut, 900.0):
            ctx.update(estado='ERROR', causa='sin resultado del broker (900 s)')
            return self._registrar(ctx)
        r = res_fut.result().result
        ctx.update(estado='COMPLETADA' if r.success else 'FALLIDA', success=r.success,
                   t_cola_s=float(r.wait_time_s), ejec_s=float(r.exec_time_s), mensaje=r.message,
                   causa='')
        if r.success and r.position_error_m == r.position_error_m:        # no NaN
            ctx['error_pos_mm'] = r.position_error_m * 1000.0
        m = RE_TIEMPOS.search(r.message or '')
        if m:
            ctx.update(t_percepcion_s=float(m.group(1)), t_ik_s=float(m.group(3)) / 1000.0,
                       t_plan_s=float(m.group(5)))
        # primer comando al brazo después de salir de la cola
        inicio = max(ctx['_t_enc'], ctx['_t_enc'] + float(r.wait_time_s) - 0.3)
        primeros = [t for t in list(self.cmds) if t >= inicio]
        if primeros:
            ctx['t_hasta_primer_cmd_s'] = primeros[0] - ctx['_t0']
            cab = ctx.get('t_captura_s')
            if isinstance(cab, (int, float)):
                ctx['t_voz_a_movimiento_s'] = cab + ctx['t_hasta_primer_cmd_s']
        self._registrar(ctx)

    @staticmethod
    def _resp(ctx):
        return {'estado': ctx.get('estado'), 'causa': ctx.get('causa', ''),
                'transcripcion': ctx.get('transcripcion', ''),
                'modo': 'texto' if ctx.get('estado') == 'MODO_TEXTO' else ctx['origen'],
                'decision': {k: ctx.get(k) for k in ('accion', 'objeto', 'color', 'prioridad',
                                                     'permitido', 'metodo', 'degradada')},
                'tiempos': {k: (round(ctx[k], 3) if isinstance(ctx.get(k), float) else ctx.get(k))
                            for k in ('t_captura_s', 't_transcripcion_s', 't_decision_s') if k in ctx}}


# ----------------------------------------------------------------------------- servidor HTTP
def crear_servidor(nodo, host, puerto):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, codigo, obj):
            b = json.dumps(obj, ensure_ascii=False).encode('utf-8')
            self.send_response(codigo)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def do_GET(self):
            self._json(200, {'ok': True, 'nodo': 'transcriptor_voz', 'modo_texto': nodo.modo_texto})

        def do_POST(self):
            try:
                n = int(self.headers.get('Content-Length', '0'))
                t0 = time.perf_counter()
                cuerpo = self.rfile.read(n)
                subida = time.perf_counter() - t0
                cliente = (self.headers.get('X-Cliente') or 'alumno').strip()[:20]
                if self.path.startswith('/audio'):
                    meta = {'subida_s': subida}
                    for cab, k, esc in (('X-Cierre-Ms', 'cierre_pc_s', 1000.0), ('X-Dur-Audio-S', 'dur_audio_s', 1.0)):
                        try:
                            meta[k] = float(self.headers.get(cab)) / esc
                        except (TypeError, ValueError):
                            pass
                    mime = self.headers.get('Content-Type') or 'audio/wav'
                    return self._json(200, nodo.procesar(cliente, audio=cuerpo, mime=mime, meta=meta))
                if self.path.startswith('/texto'):
                    frase = json.loads(cuerpo.decode('utf-8')).get('frase', '').strip()
                    if not frase:
                        return self._json(400, {'error': 'frase vacía'})
                    return self._json(200, nodo.procesar(cliente, frase=frase))
                self._json(404, {'error': 'usa POST /audio o POST /texto'})
            except Exception as e:                   # noqa: BLE001
                self._json(500, {'error': f'{type(e).__name__}: {e}'})
    return ThreadingHTTPServer((host, puerto), H)


def hilo_teclado(nodo, cliente):
    for linea in sys.stdin:
        frase = linea.strip()
        if frase:
            nodo.procesar(cliente, frase=frase)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', default='0.0.0.0')
    ap.add_argument('--puerto', type=int, default=8770)
    ap.add_argument('--modelos', nargs='+', default=MODELOS)
    ap.add_argument('--limite', type=float, default=10.0, help='tiempo límite propio de la transcripción (s)')
    ap.add_argument('--gemini-url', default=GEMINI_URL)
    ap.add_argument('--audios', default='audios_g3')
    ap.add_argument('--registro', default='voz_pedidos_g3.csv')
    ap.add_argument('--cliente', default='ana', help='cliente para --archivo')
    ap.add_argument('--cliente-teclado', default='teclado')
    ap.add_argument('--archivo', help='procesar un archivo de audio y salir')
    ap.add_argument('--simular-sin-internet', action='store_true',
                    help='prueba del modo texto sin desconectar la red')
    cfg, _ = ap.parse_known_args()

    rclpy.init()
    nodo = TranscriptorVoz(cfg)
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(nodo)
    threading.Thread(target=ex.spin, daemon=True).start()
    try:
        if not nodo.clave:
            print('AVISO: GOOGLE_API_KEY no está definida en esta terminal; todo caerá en modo texto.', flush=True)
        if cfg.archivo:
            ext = os.path.splitext(cfg.archivo)[1].lower()
            with open(cfg.archivo, 'rb') as f:
                r = nodo.procesar(cfg.cliente, audio=f.read(), mime=MIMES.get(ext, 'audio/wav'))
            print(json.dumps(r, ensure_ascii=False, indent=2))
            for h in list(nodo.hilos):
                h.join()
            return
        srv = crear_servidor(nodo, cfg.host, cfg.puerto)
        print(f'transcriptor_voz listo: escuchando audio en http://{cfg.host}:{cfg.puerto}/audio '
              f'(modelos {cfg.modelos}, límite {cfg.limite:g} s). Ctrl+C para salir.', flush=True)
        if sys.stdin.isatty():
            print('Modo texto disponible: escribe una orden aquí y pulsa Enter.', flush=True)
            threading.Thread(target=hilo_teclado, args=(nodo, cfg.cliente_teclado), daemon=True).start()
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
