#!/usr/bin/env python3
"""probar_gemini_g3.py — comprueba que la clave de Google AI Studio funciona y qué modelo usar.

Lee la clave SOLO de la variable de entorno GOOGLE_API_KEY (nunca va en el código).
Lista los modelos con generateContent y prueba varios, de uno en uno, hasta que uno responda.
Sin librerías externas.

Uso:  python3 probar_gemini_g3.py                    (prueba candidatos en orden)
      python3 probar_gemini_g3.py gemini-flash-latest (prueba solo ese modelo)
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request

BASE = 'https://generativelanguage.googleapis.com/v1beta'
TIMEOUT_S = 20
PREFERIDOS = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3-flash-preview',
              'gemini-flash-lite-latest', 'gemini-2.5-flash-lite']


class ErrorHTTP(Exception):
    pass


def pedir(url, cuerpo=None):
    clave = os.environ.get('GOOGLE_API_KEY', '')
    if not clave:
        sys.exit('Falta GOOGLE_API_KEY en ESTA terminal (read -rs GOOGLE_API_KEY; export GOOGLE_API_KEY).')
    datos = None if cuerpo is None else json.dumps(cuerpo).encode('utf-8')
    req = urllib.request.Request(url, data=datos, headers={
        'x-goog-api-key': clave, 'Content-Type': 'application/json'})
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
            return json.loads(r.read().decode('utf-8')), (time.perf_counter() - t0) * 1000
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode('utf-8'))['error']['message']
        except Exception:
            msg = '(sin detalle)'
        raise ErrorHTTP(f'HTTP {e.code}: {msg[:200]}')
    except Exception as e:
        raise ErrorHTTP(f'No se pudo contactar a Google: {type(e).__name__}: {e}')


def probar(modelo):
    cuerpo = {'contents': [{'parts': [{'text': 'Responde solo con la palabra OK.'}]}]}
    r, ms = pedir(f'{BASE}/models/{modelo}:generateContent', cuerpo)
    try:
        texto = r['candidates'][0]['content']['parts'][0]['text'].strip()
    except (KeyError, IndexError):
        texto = f'(sin texto: {json.dumps(r)[:200]})'
    return texto, ms


def main():
    try:
        resp, ms = pedir(f'{BASE}/models?pageSize=200')
    except ErrorHTTP as e:
        sys.exit(str(e))
    modelos = [m['name'].split('/', 1)[1] for m in resp.get('models', [])
               if 'generateContent' in m.get('supportedGenerationMethods', [])]
    print(f'Clave aceptada. {len(modelos)} modelos con generateContent ({ms:.0f} ms).')
    print('Modelos "gemini" tipo flash disponibles:')
    for m in modelos:
        if 'gemini' in m and 'flash' in m and not any(x in m for x in ('tts', 'image', 'live', 'native')):
            print('  ', m)

    if len(sys.argv) > 1:
        candidatos = [sys.argv[1]]
    else:
        candidatos = [m for m in PREFERIDOS if m in modelos]
        candidatos += [m for m in modelos if 'gemini' in m and 'flash' in m and m not in candidatos
                       and not any(x in m for x in ('tts', 'image', 'live', 'native', 'robotics'))]
    print()
    for modelo in candidatos[:8]:
        print(f'Probando {modelo} ... ', end='', flush=True)
        try:
            texto, ms = probar(modelo)
        except ErrorHTTP as e:
            print(f'no sirve ({e})')
            continue
        print(f'respuesta {texto!r} en {ms:.0f} ms')
        if 'OK' in texto.upper():
            print(f'\nTODO BIEN. Modelo a usar: {modelo}')
            return
    print('\nNingún candidato respondió bien. Pásame esta salida completa.')


if __name__ == '__main__':
    main()
