#!/usr/bin/env python3
"""probar_transcripcion_g3.py — manda UN audio a varios modelos de Gemini a la vez y muestra
cuánto tarda cada uno y qué responde (o qué error da). Sirve para elegir el modelo más rápido.

Lee la clave de GOOGLE_API_KEY (variable de entorno). Sin librerías externas.
Uso:  python3 probar_transcripcion_g3.py audios_g3/ARCHIVO.wav
      python3 probar_transcripcion_g3.py ARCHIVO.wav gemini-3-flash-preview gemini-3.5-flash
"""
import base64
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

BASE = 'https://generativelanguage.googleapis.com/v1beta'
MODELOS = ['gemini-3-flash-preview', 'gemini-flash-latest', 'gemini-3.1-flash-lite',
           'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.7-flash', 'gemini-3.8-flash',
           'gemini-2.5-flash-lite']
PROMPT = ('Transcribe literalmente, en español, lo que dice la persona en este audio. '
          'Responde SOLO con el texto transcrito, sin comillas ni comentarios. '
          'Si no hay voz inteligible responde exactamente: [SIN_VOZ]')
LIMITE_S = 30
resultados = {}


def probar(modelo, cuerpo, clave):
    t0 = time.perf_counter()
    req = urllib.request.Request(f'{BASE}/models/{modelo}:generateContent', data=cuerpo,
                                 headers={'x-goog-api-key': clave, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=LIMITE_S) as r:
            j = json.loads(r.read().decode('utf-8'))
        texto = ''.join(p.get('text', '') for p in j['candidates'][0]['content']['parts']
                        if not p.get('thought')).strip()
        res = f'OK  "{texto}"'
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode('utf-8'))['error']['message'][:90]
        except Exception:                            # noqa: BLE001
            msg = ''
        res = f'HTTP {e.code} {msg}'
    except Exception as e:                           # noqa: BLE001
        res = f'{type(e).__name__}: {e}'
    resultados[modelo] = (time.perf_counter() - t0, res)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    clave = os.environ.get('GOOGLE_API_KEY', '')
    if not clave:
        sys.exit('Falta GOOGLE_API_KEY en esta terminal (read -rs GOOGLE_API_KEY; export GOOGLE_API_KEY).')
    ruta = sys.argv[1]
    modelos = sys.argv[2:] or MODELOS
    mime = {'.wav': 'audio/wav', '.mp3': 'audio/mp3', '.ogg': 'audio/ogg',
            '.flac': 'audio/flac'}.get(os.path.splitext(ruta)[1].lower(), 'audio/wav')
    audio = open(ruta, 'rb').read()
    cuerpo = json.dumps({'contents': [{'parts': [{'text': PROMPT}, {'inline_data': {
        'mime_type': mime, 'data': base64.b64encode(audio).decode('ascii')}}]}],
        'generationConfig': {'temperature': 0}}).encode('utf-8')
    print(f'Audio: {ruta} ({len(audio) / 1024:.0f} KiB). Probando {len(modelos)} modelos a la vez '
          f'(límite {LIMITE_S} s cada uno)...')
    hs = [threading.Thread(target=probar, args=(m, cuerpo, clave)) for m in modelos]
    for h in hs:
        h.start()
    for h in hs:
        h.join()
    print()
    for m in sorted(resultados, key=lambda k: resultados[k][0]):
        t, r = resultados[m]
        print(f'{t:6.1f} s  {m:28s} {r}')


if __name__ == '__main__':
    main()
