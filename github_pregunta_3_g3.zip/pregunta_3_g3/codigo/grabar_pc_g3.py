#!/usr/bin/env python3
"""grabar_pc_g3.py — corre en la COMPUTADORA DEL LABORATORIO (Windows), no en la Jetson.

Graba tu voz con el micrófono de la cámara Logitech y manda el audio al nodo
transcriptor_voz que corre en la Jetson. No usa ninguna clave: la transcripción la hace
la Jetson con su propia GOOGLE_API_KEY.

Instalación (una sola vez):   pip install sounddevice
Uso:
    python grabar_pc_g3.py --listar                       (ver los micrófonos)
    python grabar_pc_g3.py --dispositivo Logitech         (grabar con ese micrófono)
Cada ronda: Enter = empezar a grabar, hablas, Enter = terminar y enviar.
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
import wave
from array import array
from datetime import datetime

try:
    import sounddevice as sd
except (ImportError, OSError) as e:
    sys.exit(f'Falta la librería de audio ({e}).\nInstálala con:  pip install sounddevice')


def elegir_dispositivo(texto):
    if texto is None:
        return None
    if texto.isdigit():
        return int(texto)
    for i, d in enumerate(sd.query_devices()):
        if d['max_input_channels'] > 0 and texto.lower() in d['name'].lower():
            return i
    sys.exit(f'No encontré un micrófono con "{texto}". Usa --listar para ver los nombres.')


def listar():
    print('Micrófonos disponibles (número: nombre):')
    for i, d in enumerate(sd.query_devices()):
        if d['max_input_channels'] > 0:
            marca = '  <-- por defecto' if i == sd.default.device[0] else ''
            print(f"  {i}: {d['name']}{marca}")


def grabar(dispositivo, rate):
    """Graba hasta que pulses Enter. Devuelve (bytes_pcm16, rate, t_fin_perf)."""
    trozos = []

    def cb(indata, frames, tiempo, estado):
        trozos.append(bytes(indata))
    try:
        flujo = sd.RawInputStream(samplerate=rate, channels=1, dtype='int16', device=dispositivo, callback=cb)
    except sd.PortAudioError:
        rate = int(sd.query_devices(dispositivo, 'input')['default_samplerate'])
        flujo = sd.RawInputStream(samplerate=rate, channels=1, dtype='int16', device=dispositivo, callback=cb)
    with flujo:
        print('>>> GRABANDO. Habla y pulsa Enter apenas termines...')
        input()
        t_fin = time.perf_counter()
    return b''.join(trozos), rate, t_fin


def a_wav(pcm, rate):
    import io
    b = io.BytesIO()
    with wave.open(b, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return b.getvalue()


def enviar(url, datos, cabeceras, espera_s=90):
    req = urllib.request.Request(url, data=datos, headers=cabeceras, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=espera_s) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        return {'estado': 'ERROR', 'causa': f'HTTP {e.code}: {e.read().decode("utf-8", "replace")[:200]}'}
    except Exception as e:                           # noqa: BLE001
        return {'estado': 'ERROR', 'causa': f'no llegué a la Jetson ({type(e).__name__}: {e})'}


def mostrar(r):
    print('-' * 60)
    if r.get('transcripcion'):
        print(f'Transcripción : "{r["transcripcion"]}"')
    d = r.get('decision') or {}
    if d.get('accion'):
        print(f'Decisión      : {d["accion"]} {d["objeto"]} {d["color"]} · prioridad {d["prioridad"]} · '
              f'permitido={d["permitido"]} · método {d["metodo"]}')
    print(f'Estado        : {r.get("estado")}  {r.get("causa", "")}')
    t = r.get('tiempos') or {}
    if t:
        print('Tiempos (s)   : ' + ' · '.join(f'{k[2:-2]} {v}' for k, v in t.items()))
    print('-' * 60)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--jetson', default='172.51.1.20')
    ap.add_argument('--puerto', type=int, default=8770)
    ap.add_argument('--cliente', default='ana')
    ap.add_argument('--dispositivo', help='número o parte del nombre del micrófono (ej. Logitech)')
    ap.add_argument('--rate', type=int, default=16000)
    ap.add_argument('--listar', action='store_true')
    ap.add_argument('--carpeta', default='audios_pc_g3')
    a = ap.parse_args()
    if a.listar:
        return listar()
    disp = elegir_dispositivo(a.dispositivo)
    base = f'http://{a.jetson}:{a.puerto}'
    try:
        urllib.request.urlopen(base + '/', timeout=5).read()
    except Exception as e:                           # noqa: BLE001
        sys.exit(f'No encuentro el nodo transcriptor_voz en {base} ({e}).\n'
                 'Revisa que esté corriendo en la Jetson y que la IP sea correcta (--jetson).')
    os.makedirs(a.carpeta, exist_ok=True)
    print(f'Conectado a {base}. Cliente: {a.cliente}.')
    while True:
        op = input('\n[Enter] grabar una orden · [t] escribirla · [q] salir: ').strip().lower()
        if op == 'q':
            return
        if op == 't':
            frase = input('Escribe la orden: ').strip()
            if frase:
                mostrar(enviar(base + '/texto', json.dumps({'frase': frase}).encode('utf-8'),
                               {'Content-Type': 'application/json', 'X-Cliente': a.cliente}))
            continue
        pcm, rate, t_fin = grabar(disp, a.rate)
        dur = len(pcm) / 2 / rate
        pico = max((abs(x) for x in array('h', pcm)), default=0)
        wav = a_wav(pcm, rate)
        ruta = os.path.join(a.carpeta, f'{datetime.now():%Y%m%d_%H%M%S}_{a.cliente}.wav')
        with open(ruta, 'wb') as f:
            f.write(wav)
        print(f'Audio: {dur:.1f} s, volumen máximo {pico}/32767 (copia en {ruta})')
        if dur < 0.5 or pico < 300:
            print('AVISO: casi no se oye nada. Revisa que sea el micrófono correcto (--listar).')
        cierre_ms = (time.perf_counter() - t_fin) * 1000.0
        r = enviar(base + '/audio', wav, {'Content-Type': 'audio/wav', 'X-Cliente': a.cliente,
                                          'X-Cierre-Ms': f'{cierre_ms:.1f}', 'X-Dur-Audio-S': f'{dur:.2f}'})
        mostrar(r)
        if r.get('estado') == 'MODO_TEXTO':
            print('La transcripción falló: modo texto. Escribe la orden que dijiste.')
            frase = input('Orden: ').strip()
            if frase:
                mostrar(enviar(base + '/texto', json.dumps({'frase': frase}).encode('utf-8'),
                               {'Content-Type': 'application/json', 'X-Cliente': a.cliente}))


if __name__ == '__main__':
    main()
