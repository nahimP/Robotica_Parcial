#!/usr/bin/env python3
"""escanear_g3 — visita las 4 posiciones de recogida, toma una foto en cada una y dice qué color ve.

La cámara va montada sobre la pinza, así que mira la posición a la que apunta el brazo.
Usa las poses 'ver_<posicion>' de poses_g3.json (enseñadas con ensenar_ver_g3.py); si faltan, cae a recoger_<posicion>_alto.
Orden de visita: azul, rojo, amarillo, verde (los nombres son las POSICIONES de las fotos de
calibración, no el color del cubo que haya ahora). Antes de cada movimiento pide Enter.
NO usar con driver_g3 ni el broker en marcha (este script abre /dev/ttyUSB0 directamente).

    python3 escanear_g3.py                  # recorre las 4 posiciones
    python3 escanear_g3.py --solo rojo      # solo una
Guarda scan_<posicion>.jpg y scan_<posicion>_raw.jpg en --salida (por defecto ~/capturas_g3).
"""
import argparse
import json
import math
import os
import sys
import time

import cv2

import capturar_g3 as cam
import probar_poses_g3 as mov

POSICIONES = ['azul', 'rojo', 'amarillo', 'verde']


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--solo', nargs='*', choices=POSICIONES)
    ap.add_argument('--archivo', default=os.path.expanduser('~/poses_g3.json'))
    ap.add_argument('--salida', default=os.path.expanduser('~/capturas_g3'))
    ap.add_argument('--vel', type=int, default=20)
    ap.add_argument('--tramo-deg', type=float, default=25.0)
    ap.add_argument('--camara', type=int, default=0)
    ap.add_argument('--area-min', type=float, default=150.0)
    ap.add_argument('--port', default='/dev/ttyUSB0')
    ap.add_argument('--volver-home', action='store_true')
    args = ap.parse_args(argv)

    P = json.load(open(args.archivo, encoding='utf-8'))['poses']
    os.makedirs(args.salida, exist_ok=True)
    from pymycobot.mycobot import MyCobot
    mc = MyCobot(args.port, 1000000)
    time.sleep(0.5)
    actual = mov.leer(mc)
    if actual is None:
        sys.exit('No se pudo leer el brazo (¿otro programa usa el puerto?).')
    resumen = {}
    try:
        for pos in (args.solo or POSICIONES):
            nombre = f'ver_{pos}' if f'ver_{pos}' in P else f'recoger_{pos}_alto'
            if nombre.startswith('recoger'):
                print(f'  (aviso: no hay pose ver_{pos}; se usa {nombre}. Enséñala con ensenar_ver_g3.py)')
            obj = P[nombre]['grados']
            seg = mov.tramos(actual, obj, args.tramo_deg)
            print(f'\n[posición {pos}] objetivo {obj} ({len(seg)} tramo(s), vel {args.vel})')
            r = input('  Enter = ir y fotografiar, s = saltar, q = terminar: ').strip().lower()
            if r == 'q':
                break
            if r == 's':
                continue
            llego = True
            for i, punto in enumerate(seg, 1):
                mc.send_angles([round(v, 2) for v in punto], args.vel)
                ok, err = mov.esperar(mc, punto)
                if not ok:
                    print(f'  tramo {i}: NO llegó (error {err}); se aborta esta posición.')
                    llego = False
                    break
            actual = mov.leer(mc) or actual
            if not llego:
                continue
            time.sleep(0.8)                      # que se aquiete la imagen
            frame = cam.leer_frame(args.camara)
            det = cam.detectar(frame, args.area_min)
            cv2.imwrite(os.path.join(args.salida, f'scan_{pos}_raw.jpg'), frame)
            cv2.imwrite(os.path.join(args.salida, f'scan_{pos}.jpg'), cam.marcar(frame, det))
            if det:
                mejor = max(det, key=lambda c: det[c]['area'])
                print(f'  ve: ' + ', '.join(f'{c} (area {int(d["area"])})' for c, d in det.items())
                      + f'  -> predomina {mejor}')
                resumen[pos] = mejor
            else:
                print('  no detecta ningún color')
                resumen[pos] = None
        if args.volver_home:
            input('\nEnter para volver a home: ')
            for punto in mov.tramos(actual, P['home']['grados'], args.tramo_deg):
                mc.send_angles([round(v, 2) for v in punto], args.vel)
                mov.esperar(mc, punto)
    except KeyboardInterrupt:
        print('\nCtrl+C: deteniendo el brazo.')
        getattr(mc, 'stop', lambda: None)()
    print('\nResumen (posición -> color visto):')
    for pos, c in resumen.items():
        print(f'  {pos:9s} -> {c}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
