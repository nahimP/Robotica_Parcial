#!/usr/bin/env python3
"""intentos_g3 — los 10 intentos de agarre de la Pregunta 2, con tabla de resultados.

Para cada intento: manda UNA orden en lenguaje natural por el mismo camino de siempre
(intérprete -> decisión -> cola del broker -> IK -> MoveIt2 -> brazo), espera el resultado y
le pregunta al operador si el cubo correcto quedó en la zona correcta (el enunciado define
éxito así; el brazo no tiene sensor para comprobarlo). Para los exitosos, el error es el que
calculó el broker: posición cartesiana pedida vs cinemática directa del RB-2 de lo leído.

Uso (Terminal 4, con el intérprete, el broker, el driver y move_group ya corriendo):
    python3 intentos_g3.py                 # 10 intentos con la lista por defecto
    python3 intentos_g3.py --n 10 --colores rojo azul verde amarillo
Salida: intentos_g3.csv, intentos_g3.md (tabla lista para el informe) y el resumen en pantalla.
"""
import argparse
import csv
import itertools
import math
import time

FRASES = {   # frases que LAYA acepta (umbral 0.50 sin tocar)
    'rojo': 'recoge el cubo rojo con urgencia',
    'azul': 'es importante que recojas el cubo azul',
    'verde': 'es importante que recojas el cubo verde',
    'amarillo': 'cuando puedas agarra el cubo amarillo',
}
CAMPOS = ['intento', 'cliente', 'frase', 'color_pedido', 'prioridad', 'estado', 'exito',
          'error_pos_mm', 'espera_s', 'ejec_s', 'observacion']


def si_no(pregunta):
    while True:
        r = input(pregunta + ' [s/n]: ').strip().lower()
        if r in ('s', 'si', 'sí'):
            return True
        if r in ('n', 'no'):
            return False


def fila_intento(k, cliente, frase, color, fila_orq, exito, obs):
    """Arma la fila de la tabla a partir de lo que registró el orquestador."""
    err = fila_orq.get('error_pos_m', '')
    ok_err = exito and err not in ('', None) and not (isinstance(err, float) and math.isnan(err))
    return {'intento': k, 'cliente': cliente, 'frase': frase, 'color_pedido': color,
            'prioridad': fila_orq.get('prioridad', ''), 'estado': fila_orq.get('estado', ''),
            'exito': 'sí' if exito else 'no',
            'error_pos_mm': round(float(err) * 1000, 2) if ok_err else '',
            'espera_s': fila_orq.get('espera_s', ''), 'ejec_s': fila_orq.get('ejec_s', ''),
            'observacion': obs or (fila_orq.get('causa') or fila_orq.get('mensaje', ''))[:120]}


def resumen(filas):
    n = len(filas)
    ok = [f for f in filas if f['exito'] == 'sí']
    errs = [f['error_pos_mm'] for f in ok if f['error_pos_mm'] != '']
    return {'n': n, 'exitos': len(ok), 'tasa': (100.0 * len(ok) / n) if n else 0.0,
            'err_medio': (sum(errs) / len(errs)) if errs else float('nan'),
            'err_max': max(errs) if errs else float('nan')}


def tabla_md(filas, r):
    t = ['| # | Pedido | Resultado | Éxito | Error (mm) | Espera (s) | Ejecución (s) | Observación |',
         '|---|---|---|---|---|---|---|---|']
    for f in filas:
        t.append(f"| {f['intento']} | {f['color_pedido']} (prio {f['prioridad']}) | {f['estado']} | {f['exito']} | "
                 f"{f['error_pos_mm'] if f['error_pos_mm'] != '' else '—'} | {f['espera_s']} | {f['ejec_s']} | {f['observacion']} |")
    t.append('')
    t.append(f"**Tasa de éxito: {r['exitos']}/{r['n']} = {r['tasa']:.0f} %.** "
             + (f"Error medio de los exitosos: {r['err_medio']:.2f} mm (máximo {r['err_max']:.2f} mm)."
                if r['exitos'] and not math.isnan(r['err_medio']) else ''))
    return '\n'.join(t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=10)
    ap.add_argument('--colores', nargs='+', default=['rojo', 'azul', 'verde', 'amarillo'],
                    choices=list(FRASES))
    ap.add_argument('--cliente', default='ana')
    ap.add_argument('--csv', default='intentos_g3.csv')
    ap.add_argument('--md', default='intentos_g3.md')
    a = ap.parse_args()

    import threading
    import rclpy
    from rclpy.executors import MultiThreadedExecutor
    import orquestador_g3 as orq

    rclpy.init()
    registro = []
    nodo = orq.OrquestadorG3(registro)
    ex = MultiThreadedExecutor(num_threads=4)
    ex.add_node(nodo)
    threading.Thread(target=ex.spin, daemon=True).start()

    filas = []
    ciclo = itertools.cycle(a.colores)
    try:
        for k in range(1, a.n + 1):
            color = next(ciclo)
            frase = FRASES[color]
            print(f'\n=== Intento {k}/{a.n}: pedir el cubo {color} ===')
            input('Pon los 4 cubos en las esquinas (en cualquier orden) y pulsa Enter para enviar la orden... ')
            antes = len(registro)
            t0 = time.time()
            nodo.procesar(a.cliente, frase)          # bloquea hasta COMPLETADA / FALLIDA / RECHAZADA
            nuevas = registro[antes:]
            final = nuevas[-1] if nuevas else {'estado': 'ERROR', 'causa': 'sin respuesta'}
            exito, obs = False, ''
            if final.get('estado') == 'COMPLETADA':
                exito = si_no(f'¿El cubo {color} quedó depositado en la zona {color}?')
                if not exito:
                    obs = input('¿Qué pasó? (corto): ').strip()
            filas.append(fila_intento(k, a.cliente, frase, color, final, exito, obs))
            print(f"  -> {final.get('estado')} · éxito={filas[-1]['exito']} · "
                  f"error={filas[-1]['error_pos_mm'] or '—'} mm · {time.time() - t0:.0f} s")
    except KeyboardInterrupt:
        print('\nInterrumpido: se guardan los intentos hechos hasta ahora.')
    finally:
        if filas:
            with open(a.csv, 'w', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=CAMPOS)
                w.writeheader()
                w.writerows(filas)
            r = resumen(filas)
            md = tabla_md(filas, r)
            with open(a.md, 'w', encoding='utf-8') as f:
                f.write(md + '\n')
            print('\n' + md)
            print(f'\nGuardado: {a.csv} y {a.md}')
        nodo.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
