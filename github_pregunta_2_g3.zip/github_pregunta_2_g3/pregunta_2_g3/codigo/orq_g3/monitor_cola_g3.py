#!/usr/bin/env python3
"""monitor_cola_g3 — muestra en vivo la cola del broker (/arm_g3/queue_state). SOLO LEE.

Sirve para el video de la demostración y como evidencia. Redibuja una tabla cuando cambia
quién ejecuta o quién espera (y cada segundo para el tiempo transcurrido).

    python3 monitor_cola_g3.py                  # tabla en vivo
    python3 monitor_cola_g3.py --csv cola_g3.csv   # además guarda cada cambio en un CSV
No publica nada: no puede mover el brazo ni alterar la cola.
"""
import argparse
import csv
import os
import sys
import time


def formatear(msg, t0, ancho=78):
    """Texto de la tabla para un mensaje QueueState (función pura, se puede probar sin ROS)."""
    L = []
    L.append('=' * ancho)
    L.append(f' COLA DEL BROKER (RB-2)  ·  t = {time.time() - t0:7.1f} s')
    L.append('=' * ancho)
    if msg.executing_client:
        L.append(f' EJECUTANDO : {msg.executing_client:<12} lleva {msg.executing_elapsed_s:6.1f} s')
    else:
        L.append(' EJECUTANDO : (brazo libre)')
    L.append('-' * ancho)
    L.append(f' EN COLA ({msg.queue_length}):   {"puesto":<7}{"cliente":<14}{"prioridad":<11}{"espera (s)":<10}')
    n = len(msg.queued_clients)
    for i in range(n):
        esp = msg.queued_wait_s[i] if i < len(msg.queued_wait_s) else 0.0
        pr = msg.queued_priorities[i] if i < len(msg.queued_priorities) else '?'
        L.append(f'               {i + 1:<7}{msg.queued_clients[i]:<14}{pr!s:<11}{esp:<10.1f}')
    if n == 0:
        L.append('               (vacía)')
    L.append('-' * ancho)
    L.append(f' aceptados {msg.total_accepted}  ·  rechazados {msg.total_rejected}  ·  completados {msg.total_completed}')
    L.append('=' * ancho)
    return '\n'.join(L)


def firma(msg):
    return (msg.executing_client, tuple(msg.queued_clients), tuple(msg.queued_priorities),
            msg.total_accepted, msg.total_rejected, msg.total_completed)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--csv', default='')
    ap.add_argument('--sin-limpiar', action='store_true', help='no borrar la pantalla (útil con logs)')
    a, _ = ap.parse_known_args(argv)

    import rclpy
    from rclpy.node import Node
    from arm_broker_interfaces_g3.msg import QueueState

    rclpy.init()
    nodo = Node('monitor_cola_g3')
    t0 = time.time()
    estado = {'firma': None, 'ultimo': 0.0}
    f_csv = w = None
    if a.csv:
        nuevo = not os.path.exists(a.csv)
        f_csv = open(a.csv, 'a', newline='', encoding='utf-8')
        w = csv.writer(f_csv)
        if nuevo:
            w.writerow(['t_epoch', 'ejecutando', 'en_cola', 'prioridades', 'aceptados', 'rechazados', 'completados'])

    def cb(msg):
        f, ahora = firma(msg), time.time()
        cambio = f != estado['firma']
        if not cambio and ahora - estado['ultimo'] < 1.0:
            return
        estado['firma'], estado['ultimo'] = f, ahora
        if not a.sin_limpiar:
            sys.stdout.write('\033[2J\033[H')
        print(formatear(msg, t0), flush=True)
        if cambio and w:
            w.writerow([round(ahora, 3), msg.executing_client, '|'.join(msg.queued_clients),
                        '|'.join(str(p) for p in msg.queued_priorities),
                        msg.total_accepted, msg.total_rejected, msg.total_completed])
            f_csv.flush()

    nodo.create_subscription(QueueState, '/arm_g3/queue_state', cb, 10)
    print('Esperando mensajes de /arm_g3/queue_state ... (Ctrl+C para salir)', flush=True)
    try:
        rclpy.spin(nodo)
    except KeyboardInterrupt:
        pass
    finally:
        if f_csv:
            f_csv.close()
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
