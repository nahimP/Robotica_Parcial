#!/usr/bin/env python3
"""probar_poses_g3 — lleva el brazo, UNA pose a la vez, a las poses de poses_g3.json.

Sirve para comprobar físicamente cada pose antes de usarlas en el broker.
Seguridad:
  * Pide Enter ANTES de cada movimiento (q = terminar, s = saltar esa pose).
  * Parte cada movimiento en tramos de máx. --tramo-deg grados (por defecto 25).
  * Velocidad baja por defecto (--vel 20).
  * Verifica límites con el fk.py del broker y compara el ángulo real al llegar.
  * Ctrl+C detiene el brazo (mc.stop()).
  * --simular no abre el puerto: solo muestra lo que haría.
NO usar mientras corra driver_g3 u otro programa que tenga /dev/ttyUSB0.

Ejemplos (Jetson, con rb2_ws cargado):
    python3 probar_poses_g3.py --simular home recoger_rojo_alto recoger_rojo_bajo
    python3 probar_poses_g3.py home recoger_rojo_alto
    python3 probar_poses_g3.py pinza_abrir pinza_cerrar
"""
import argparse
import json
import math
import os
import sys
import time


def tramos(a, b, max_deg):
    n = max(1, math.ceil(max(abs(x - y) for x, y in zip(a, b)) / max_deg))
    return [[x + (y - x) * i / n for x, y in zip(a, b)] for i in range(1, n + 1)]


def leer(mc, intentos=5):
    for _ in range(intentos):
        v = mc.get_angles()
        if isinstance(v, (list, tuple)) and len(v) == 6 and all(isinstance(x, (int, float)) and math.isfinite(x) for x in v):
            return [float(x) for x in v]
        time.sleep(0.2)
    return None


def esperar(mc, objetivo, tol=3.0, timeout=15.0):
    t0 = time.time()
    err = None
    while time.time() - t0 < timeout:
        time.sleep(0.4)
        a = leer(mc)
        if a is None:
            continue
        err = max(abs(x - y) for x, y in zip(a, objetivo))
        if err <= tol:
            return True, err
    return False, err


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('poses', nargs='+', help='nombres de poses, o pinza_abrir / pinza_cerrar')
    ap.add_argument('--archivo', default=os.path.expanduser('~/poses_g3.json'))
    ap.add_argument('--vel', type=int, default=20)
    ap.add_argument('--tramo-deg', type=float, default=25.0)
    ap.add_argument('--port', default='/dev/ttyUSB0')
    ap.add_argument('--simular', action='store_true')
    args = ap.parse_args(argv)

    datos = json.load(open(args.archivo, encoding='utf-8'))
    P, G = datos['poses'], datos['gripper']
    for n in args.poses:
        if n not in P and not n.startswith('pinza_'):
            sys.exit(f'No existe la pose "{n}". Disponibles: {", ".join(P)}')
    try:
        from arm_broker_g3 import fk
    except Exception:
        fk = None

    mc = None
    if not args.simular:
        from pymycobot.mycobot import MyCobot
        mc = MyCobot(args.port, args.baud if hasattr(args, 'baud') else 1000000)
        time.sleep(0.5)
        actual = leer(mc)
        if actual is None:
            sys.exit('No se pudo leer el brazo (¿otro programa usa el puerto?).')
    else:
        actual = [0, 0, 0, 0, 0, -45]
    print(f'Ángulos actuales: {[round(v, 1) for v in actual]}')

    try:
        for n in args.poses:
            if n.startswith('pinza_'):
                v = G['abierto'] if n == 'pinza_abrir' else G['cerrado']
                r = input(f'\n[{n}] pinza -> {v}. Enter = ejecutar, s = saltar, q = terminar: ').strip().lower()
                if r == 'q':
                    break
                if r == 's':
                    continue
                if mc:
                    mc.set_gripper_value(v, 40)
                    time.sleep(1.5)
                continue
            obj = P[n]['grados']
            if fk:
                ok1, m1 = fk.dentro_de_limites([math.radians(v) for v in obj])
                ok2, m2 = fk.dentro_del_workspace([math.radians(v) for v in obj])
                if not (ok1 and ok2):
                    print(f'  {n}: RECHAZADA por fk ({m1 or m2}). No se mueve.')
                    continue
            seg = tramos(actual, obj, args.tramo_deg)
            print(f'\n[{n}] objetivo {obj}  xyz_mm={P[n].get("xyz_mm")}  origen: {P[n].get("origen", "-")}')
            print(f'  {len(seg)} tramo(s) a vel {args.vel}. Mano cerca del brazo.')
            r = input('  Enter = mover, s = saltar, q = terminar: ').strip().lower()
            if r == 'q':
                break
            if r == 's':
                continue
            for i, punto in enumerate(seg, 1):
                if mc:
                    mc.send_angles([round(v, 2) for v in punto], args.vel)
                    ok, err = esperar(mc, punto)
                    print(f'  tramo {i}/{len(seg)}: {"llegó" if ok else "NO llegó"} (error máx {err if err is None else round(err, 1)}°)')
                    if not ok:
                        print('  Abortado este movimiento: no llegó al tramo.')
                        break
                else:
                    print(f'  [simulación] tramo {i}/{len(seg)} -> {[round(v, 1) for v in punto]}')
            actual = leer(mc) if mc else obj
    except KeyboardInterrupt:
        print('\nCtrl+C: deteniendo el brazo.')
        if mc:
            getattr(mc, 'stop', lambda: None)()
    print('Fin.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
