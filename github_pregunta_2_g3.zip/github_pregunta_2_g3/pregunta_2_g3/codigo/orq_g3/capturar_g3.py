#!/usr/bin/env python3
"""capturar_g3 — toma UNA foto con la cámara y detecta los 4 colores. NO mueve el brazo.

Sirve para (1) ver qué ve la cámara desde la pose de inspección y (2) afinar los rangos
de color. Guarda:
    captura_g3_raw.jpg   foto tal cual
    captura_g3.jpg       foto con cada cubo detectado marcado (color, área, centro)
Imprime el centro (en píxeles) de cada color encontrado.

Uso (Jetson; la cámara no debe estar en uso por un notebook de Jupyter):
    python3 capturar_g3.py
    python3 capturar_g3.py --camara 0 --salida ~/capturas_g3
"""
import argparse
import os
import sys
import time

import cv2
import numpy as np

# Rangos HSV (OpenCV: H 0-179). Parten de los del código del reto antiguo.
# El rojo da la vuelta en H (0-10 y 170-179), por eso tiene dos rangos.
RANGOS = {
    'rojo':     [((0, 120, 70), (10, 255, 255)), ((170, 120, 70), (179, 255, 255))],
    'azul':     [((100, 150, 50), (140, 255, 255))],
    'verde':    [((40, 100, 50), (80, 255, 255))],
    'amarillo': [((20, 100, 100), (35, 255, 255))],
}
AREA_MIN = 400          # píxeles; por debajo se ignora como ruido
BGR = {'rojo': (0, 0, 255), 'azul': (255, 0, 0), 'verde': (0, 200, 0), 'amarillo': (0, 220, 255)}


def detectar(frame, area_min=AREA_MIN, rangos=RANGOS):
    """Devuelve {color: {'centro': (cx, cy), 'area': px, 'caja': (x, y, w, h)}} (el mayor por color)."""
    hsv = cv2.cvtColor(cv2.GaussianBlur(frame, (5, 5), 0), cv2.COLOR_BGR2HSV)
    kernel = np.ones((5, 5), np.uint8)
    out = {}
    for color, lista in rangos.items():
        m = np.zeros(hsv.shape[:2], np.uint8)
        for lo, hi in lista:
            m |= cv2.inRange(hsv, np.array(lo), np.array(hi))
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, kernel)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel)
        cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cs:
            continue
        c = max(cs, key=cv2.contourArea)
        a = cv2.contourArea(c)
        if a < area_min:
            continue
        M = cv2.moments(c)
        out[color] = {'centro': (M['m10'] / M['m00'], M['m01'] / M['m00']),
                      'area': a, 'caja': cv2.boundingRect(c)}
    return out


def marcar(frame, det):
    img = frame.copy()
    for color, d in det.items():
        x, y, w, h = d['caja']
        cv2.rectangle(img, (x, y), (x + w, y + h), BGR[color], 2)
        cx, cy = map(int, d['centro'])
        cv2.circle(img, (cx, cy), 4, BGR[color], -1)
        cv2.putText(img, f'{color} {int(d["area"])}', (x, max(15, y - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, BGR[color], 2)
    return img


def leer_frame(indice=0, ancho=640, alto=480, descartar=10):
    cap = cv2.VideoCapture(indice)
    if not cap.isOpened():
        raise RuntimeError(f'No se pudo abrir la cámara {indice} (¿la usa un notebook de Jupyter?)')
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, ancho)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, alto)
    try:
        frame = None
        for _ in range(descartar):          # que se asiente la exposición
            ok, f = cap.read()
            if ok:
                frame = f
            time.sleep(0.05)
        if frame is None:
            raise RuntimeError('La cámara no entregó imágenes')
        return frame
    finally:
        cap.release()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--camara', type=int, default=0)
    ap.add_argument('--salida', default='.')
    ap.add_argument('--area-min', type=float, default=AREA_MIN)
    args = ap.parse_args(argv)
    os.makedirs(os.path.expanduser(args.salida), exist_ok=True)
    frame = leer_frame(args.camara)
    det = detectar(frame, args.area_min)
    raw = os.path.join(os.path.expanduser(args.salida), 'captura_g3_raw.jpg')
    anot = os.path.join(os.path.expanduser(args.salida), 'captura_g3.jpg')
    cv2.imwrite(raw, frame)
    cv2.imwrite(anot, marcar(frame, det))
    print(f'Imagen {frame.shape[1]}x{frame.shape[0]} guardada en {anot}')
    for c in ('rojo', 'azul', 'verde', 'amarillo'):
        if c in det:
            cx, cy = det[c]['centro']
            print(f'  {c:9s} centro=({cx:6.1f}, {cy:6.1f})  area={int(det[c]["area"])}')
        else:
            print(f'  {c:9s} NO detectado')
    return 0


if __name__ == '__main__':
    sys.exit(main())
