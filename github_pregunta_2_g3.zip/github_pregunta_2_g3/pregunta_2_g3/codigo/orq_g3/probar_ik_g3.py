#!/usr/bin/env python3
"""probar_ik_g3 — prueba de la cinemática inversa SIN brazo y SIN ROS corriendo.

Lee ~/poses_g3.json, arma los objetivos cartesianos (calibración con la FK del RB-2) y para cada
uno resuelve la IK, mostrando: posición pedida, tiempo, error y cuánto se aleja de la pose enseñada.

Uso (cualquier terminal con ~/rb2_ws/install/setup.bash cargado):
    python3 probar_ik_g3.py
"""
import argparse
import math
import os
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--poses', default=os.path.expanduser('~/poses_g3.json'))
    a = ap.parse_args()
    try:
        from arm_broker_g3 import fk, ik_g3, pickplace_g3
    except Exception as e:
        sys.exit(f'No pude importar arm_broker_g3 / ik_g3 ({e}). ¿Cargaste ~/rb2_ws/install/setup.bash '
                 'y reconstruiste el paquete?')
    poses, _ = pickplace_g3.cargar_poses(a.poses)
    obj = ik_g3.objetivos_desde_poses(poses)
    home = [math.radians(v) for v in poses['home']]
    print(f'{len(obj)} objetivos cartesianos desde {a.poses}\n')
    print('La IK resuelve cada objetivo (x, y, z, orientación) en DOS formas:')
    print('  A) desde cero (semilla = home): la IK encuentra los ángulos por sí sola.')
    print('  B) con semilla = pose enseñada: lo que usa el broker (fija la rama del codo).\n')
    print(f'{"objetivo":24s} {"x":>7s} {"y":>7s} {"z":>7s} | {"A: ms":>6s} {"iter":>4s} {"err mm":>7s} {"Δ vs enseñada":>14s} | {"B: ms":>6s} {"Δ":>5s}')
    malos = 0
    for nombre in sorted(obj):
        o = obj[nombre]
        ref = [math.radians(v) for v in o['semilla']]
        x, y, z = (float(v) for v in o['T'][:3, 3])
        rA = ik_g3.resolver(o['T'], [home])
        dA = math.degrees(max(abs(p - q) for p, q in zip(rA['q'], ref)))
        rB = ik_g3.resolver(o['T'], [ref])
        dB = math.degrees(max(abs(p - q) for p, q in zip(rB['q'], ref)))
        ok = (rA['ok'] and rB['ok'] and fk.dentro_de_limites(rB['q'])[0]
              and fk.dentro_del_workspace(rB['q'])[0])
        malos += not ok
        rama = '' if dA < 5 else '  (otra rama del codo)'
        print(f'{nombre:24s} {x:7.1f} {y:7.1f} {z:7.1f} | {rA["t_ms"]:6.1f} {rA["iteraciones"]:4d} {rA["err_pos_mm"]:7.3f} '
              f'{dA:12.1f}° | {rB["t_ms"]:6.1f} {dB:4.1f}°{rama}{"" if ok else "   <-- PROBLEMA"}')
    print('\nTODO BIEN' if not malos else f'\n{malos} objetivos con problema')


if __name__ == '__main__':
    main()
