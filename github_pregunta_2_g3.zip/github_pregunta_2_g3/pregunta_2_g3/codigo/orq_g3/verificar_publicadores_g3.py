#!/usr/bin/env python3
"""verificar_publicadores_g3 — evidencia de la regla del publicador único (Pregunta 2).

Con el sistema corriendo, muestra quién PUBLICA y quién ESCUCHA los tópicos que mueven el brazo,
y avisa si existe algún controlador de trayectorias (follow_joint_trajectory) que pudiera
mandar comandos. No publica nada.

Uso:  python3 verificar_publicadores_g3.py
"""
import sys
import time

import rclpy
from rclpy.node import Node

COMANDOS = ['/arm_g3/joint_command', '/arm_g3/gripper_command']
ESTADO = ['/arm_g3/joint_feedback', '/joint_states', '/arm_g3/queue_state']
PERMITIDO = 'arm_broker_g3'     # el único que puede publicar comandos


def main():
    rclpy.init()
    nodo = Node('verificador_g3')
    fin = time.time() + 6.0
    while time.time() < fin:               # dejar que el descubrimiento termine
        rclpy.spin_once(nodo, timeout_sec=0.2)
    ok = True
    visto_broker = False
    print('=== TÓPICOS DE COMANDO (solo el broker puede publicar aquí) ===')
    for t in COMANDOS:
        pubs = nodo.get_publishers_info_by_topic(t)
        subs = nodo.get_subscriptions_info_by_topic(t)
        nombres = sorted({p.node_name for p in pubs})
        print(f'{t}\n   publicadores: {nombres or "(ninguno visible)"}\n   suscriptores: {sorted({s.node_name for s in subs}) or "(ninguno visible)"}')
        if any(n != PERMITIDO for n in nombres):
            ok = False
            print('   <-- PROBLEMA: hay un publicador que no es el broker')
        if PERMITIDO in nombres:
            visto_broker = True
        if not pubs:
            print('   (sin publicadores visibles: ¿está corriendo el broker?)')
    print('\n=== TÓPICOS DE ESTADO (informan, no mueven) ===')
    for t in ESTADO:
        pubs = nodo.get_publishers_info_by_topic(t)
        print(f'{t}\n   publicadores: {sorted({p.node_name for p in pubs}) or "(ninguno visible)"}')
    # Un servidor de FollowJointTrajectory PUBLICA en .../_action/status; un cliente (MoveIt2 en
    # espera) solo se suscribe. Si nadie publica ahí, no hay controlador al que mandar trayectorias.
    topicos_ctrl = [n for n, _ in nodo.get_topic_names_and_types()
                    if 'follow_joint_trajectory' in n and n.endswith('/_action/status')]
    servidores = {t: sorted({p.node_name for p in nodo.get_publishers_info_by_topic(t)})
                  for t in topicos_ctrl}
    clientes = {t: sorted({p.node_name for p in nodo.get_subscriptions_info_by_topic(t)})
                for t in topicos_ctrl}
    print('\n=== CONTROLADORES DE TRAYECTORIA (servidores de follow_joint_trajectory) ===')
    if not topicos_ctrl:
        print('   ninguno: MoveIt2 solo planifica')
    for t in topicos_ctrl:
        print(f'   {t}\n      servidor (publica): {servidores[t] or "NINGUNO"}\n      clientes (escuchan): {clientes[t]}')
        if servidores[t]:
            ok = False
            print('      <-- PROBLEMA: hay un servidor/controlador que puede recibir trayectorias')
        else:
            print('      (solo un cliente en espera: no hay a quién mandarle una trayectoria)')
    nombres_nodos = sorted(n for n, _ in nodo.get_node_names_and_namespaces())
    print('\nNodos vivos:', ', '.join(nombres_nodos))
    if not ok:
        resultado = 'REVISAR (ver <-- PROBLEMA)'
    elif not visto_broker:
        resultado = ('NO CONCLUYENTE: no se vio al broker publicando, así que esta terminal no está '
                     'descubriendo los tópicos; no se puede afirmar nada. Probar desde otra terminal.')
    else:
        resultado = 'CUMPLE la regla del publicador único (solo arm_broker_g3 publica comandos)'
    print('\nRESULTADO:', resultado)
    nodo.destroy_node()
    rclpy.shutdown()
    sys.exit(0 if ok and visto_broker else 1)


if __name__ == '__main__':
    main()
