#!/usr/bin/env python3
"""orquestador_g3 — cliente de la Pregunta 2 (corre en la Raspberry o en el Jetson).

frase -> /interpretar_orden (P1) -> rechazo previo si no es válida -> acción PickPlace
del broker (prioridad = la que devolvió el modelo). NUNCA publica al brazo.

Un integrante:
    ros2 run ... orquestador_g3 --cliente ana --frase "recoge el cubo rojo con urgencia"
Cuatro integrantes en paralelo (demostración), un hilo por integrante:
    orquestador_g3 --paralelo "ana:recoge el cubo rojo con urgencia" \
                              "luis:toma el cubo azul" "eva:recoge el cubo verde" \
                              "pedro:tira el cubo amarillo al suelo"
Cada pedido queda registrado en --registro (CSV) como evidencia.
"""
import argparse
import csv
import threading
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from ordenes_interfaces_g3.srv import InterpretarOrden
from arm_broker_interfaces_g3.action import PickPlace

from decision_g3 import validar_decision

CAMPOS = ['t_epoch', 'cliente', 'frase', 'accion', 'objeto', 'color', 'prioridad',
          'permitido', 'metodo', 'degradada', 'estado', 'causa', 'success',
          'espera_s', 'ejec_s', 'error_pos_m', 'mensaje']


class OrquestadorG3(Node):

    def __init__(self, registro):
        super().__init__('orquestador_g3')
        self.interprete = self.create_client(InterpretarOrden, '/interpretar_orden')
        self.broker = ActionClient(self, PickPlace, '/pick_place_g3')
        self.registro = registro
        self.lock = threading.Lock()

    def _esperar(self, future, timeout):
        ev = threading.Event()
        future.add_done_callback(lambda _: ev.set())
        return ev.wait(timeout) and future.done()

    def _anotar(self, fila):
        fila.setdefault('t_epoch', round(time.time(), 3))
        with self.lock:
            self.registro.append(fila)
        print(f"[{fila['cliente']}] {fila['estado']} · {fila.get('causa') or fila.get('mensaje', '')}", flush=True)

    def procesar(self, cliente, frase):
        base = {'cliente': cliente, 'frase': frase}
        if not self.interprete.wait_for_service(timeout_sec=5.0):
            return self._anotar({**base, 'estado': 'ERROR', 'causa': 'intérprete no disponible'})
        req = InterpretarOrden.Request()
        req.frase, req.forzar_metodo = frase, ''
        fut = self.interprete.call_async(req)
        if not self._esperar(fut, 15.0) or fut.exception():
            return self._anotar({**base, 'estado': 'ERROR', 'causa': 'el intérprete no respondió'})
        d = fut.result()
        base.update(accion=d.accion, objeto=d.objeto, color=d.color, prioridad=d.prioridad,
                    permitido=d.permitido, metodo=d.metodo, degradada=d.degradada)

        ok, causa, objeto = validar_decision(d)
        if not ok:   # rechazo ANTES de encolar, con su causa
            return self._anotar({**base, 'estado': 'RECHAZADA_ANTES_DE_COLA', 'causa': causa})

        if not self.broker.wait_for_server(timeout_sec=5.0):
            return self._anotar({**base, 'estado': 'ERROR', 'causa': 'broker no disponible'})
        goal = PickPlace.Goal()
        goal.client_id, goal.accion, goal.objeto, goal.color = cliente, d.accion, objeto, d.color
        goal.priority = int(d.prioridad)      # prioridad = la del modelo, nunca escrita a mano
        fut = self.broker.send_goal_async(goal)
        if not self._esperar(fut, 10.0):
            return self._anotar({**base, 'estado': 'ERROR', 'causa': 'el broker no respondió al pedido'})
        handle = fut.result()
        if not handle.accepted:
            return self._anotar({**base, 'estado': 'RECHAZADA_POR_BROKER',
                                 'causa': 'el broker rechazó el pedido (cola llena o solicitud inválida)'})
        self._anotar({**base, 'estado': 'ENCOLADA', 'causa': f'prioridad {goal.priority}'})
        res_fut = handle.get_result_async()
        if not self._esperar(res_fut, 900.0):
            return self._anotar({**base, 'estado': 'ERROR', 'causa': 'sin resultado del broker (900 s)'})
        r = res_fut.result().result
        self._anotar({**base, 'estado': 'COMPLETADA' if r.success else 'FALLIDA', 'success': r.success,
                      'espera_s': round(r.wait_time_s, 3), 'ejec_s': round(r.exec_time_s, 3),
                      'error_pos_m': r.position_error_m, 'mensaje': r.message})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cliente', default='alumno')
    ap.add_argument('--frase')
    ap.add_argument('--paralelo', nargs='+', help='lista "cliente:frase" (se lanzan a la vez)')
    ap.add_argument('--registro', default='registro_pedidos_g3.csv')
    a, _ = ap.parse_known_args()
    if not a.frase and not a.paralelo:
        ap.error('indica --frase o --paralelo')

    pedidos = ([tuple(p.split(':', 1)) for p in a.paralelo] if a.paralelo
               else [(a.cliente, a.frase)])
    registro = []
    rclpy.init()
    nodo = OrquestadorG3(registro)
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(nodo)
    threading.Thread(target=ex.spin, daemon=True).start()
    try:
        barrera = threading.Barrier(len(pedidos))   # salen todos a la vez
        def tarea(c, f):
            barrera.wait()
            nodo.procesar(c.strip(), f.strip())
        hilos = [threading.Thread(target=tarea, args=p) for p in pedidos]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()
    finally:
        with open(a.registro, 'a', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=CAMPOS)
            if f.tell() == 0:
                w.writeheader()
            w.writerows({k: r.get(k, '') for k in CAMPOS} for r in registro)
        print(f'Registro guardado en {a.registro}')
        nodo.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
