#!/usr/bin/env python3
"""crear_poses_g3 — arma poses_g3.json SIN tocar el brazo.

Junta los ángulos que el grupo 3 ya tenía medidos:
  * RECOGIDA de cada cubo: de las fotos del panel de sliders (grados J1..J6).
  * DEPÓSITO por color: del código del Nivel 5 del reto antiguo.
  * home: [0,0,0,0,0,-45] (el brazo lo reportó así: ~[1,-1,-1,-1,1,-45]).
Las poses "ver_<color>" (donde la cámara mira cada posición) vienen de los sliders del grupo.
Las poses "alto" de recogida no estaban medidas: se DERIVAN a mitad de camino entre
home y la pose baja (ese tramo es el mismo que ya hacía send_angles en el reto antiguo).
Cada pose se valida con el fk.py del broker (límites y alcance).

Uso (Jetson, con ~/rb2_ws/install/setup.bash cargado):
    python3 crear_poses_g3.py            # escribe ~/poses_g3.json
    python3 crear_poses_g3.py --salida /tmp/prueba.json
"""
import argparse
import json
import math
import os
import shutil
import sys
import time

HOME = [0, 0, 0, 0, 0, -45]

# De las fotos (orden J1..J6, grados). Las fotos eran algo borrosas: VERIFICAR.
RECOGIDA = {
    'azul':     [35, -37, -75, 6, 20, -12],
    'rojo':     [-3, -33, -80, 4, 4, -33],
    'amarillo': [30, -86, 26, -25, 1, -25],
    'verde':    [0, -60, -23, -9, 2, -51],
}
# Del código del Nivel 5 (reto antiguo): (alto, bajo)
DEPOSITO = {
    'rojo':     ([83, 0, -74, 4, -4, -48],  [90, -37, -74, 4, -4, -48]),
    'azul':     ([133, 0, -83, 4, -4, -48], [132, -18, -88, 2, 0, -45]),
    'verde':    ([107, 0, -85, -4, -3, -45], [112, -27, -85, -4, -3, -45]),
    'amarillo': ([65, 0, -70, 11, -4, -48], [72, -39, -70, 11, -4, -48]),
}
# Poses de MIRADA (la cámara va sobre la pinza), de los sliders que mostró el grupo.
# Asignadas por geometría (J1 y extensión comparadas con las poses de recogida):
#   verde = fondo/derecha, amarillo = fondo/izquierda, azul = frente/izquierda, rojo = frente/derecha
# Se verifica físicamente con escanear_g3.py con los cubos en su posición original.
VER = {
    'verde':    [0, -22, -56, 0, 0, -45],
    'amarillo': [30, -22, -56, 0, 0, -45],
    'azul':     [49, -8, -61, -32, 0, -45],
    'rojo':     [3, -8, -61, -32, 0, -45],
}
FRACCION_ALTO = 0.5   # alto = home + 0.5 * (bajo - home)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--salida', default=os.path.expanduser('~/poses_g3.json'))
    args = ap.parse_args(argv)
    try:
        from arm_broker_g3 import fk
    except Exception as e:
        sys.exit(f'No se pudo importar arm_broker_g3.fk ({e}). ¿Cargaste ~/rb2_ws/install/setup.bash?')

    poses = {}

    def agregar(nombre, grados, origen):
        grados = [round(float(v), 2) for v in grados]
        q = [math.radians(v) for v in grados]
        avisos = []
        ok, m = fk.dentro_de_limites(q)
        if not ok:
            avisos.append('LÍMITES: ' + m)
        ok, m = fk.dentro_del_workspace(q)
        if not ok:
            avisos.append('WORKSPACE: ' + m)
        x, y, z = fk.fk(q)
        poses[nombre] = {'grados': grados, 'xyz_mm': [round(x, 1), round(y, 1), round(z, 1)],
                         'origen': origen, 'avisos': avisos,
                         'fecha': time.strftime('%Y-%m-%d %H:%M:%S')}

    agregar('home', HOME, 'reto antiguo (alto_recogida) / lectura del brazo')
    for c, bajo in RECOGIDA.items():
        alto = [h + FRACCION_ALTO * (b - h) for h, b in zip(HOME, bajo)]
        agregar(f'recoger_{c}_alto', alto, 'derivada: mitad del camino home -> bajo')
        agregar(f'recoger_{c}_bajo', bajo, 'foto del panel de sliders')
    for c, g in VER.items():
        agregar(f'ver_{c}', g, 'sliders del grupo (pose de mirada de la cámara)')
    for c, (alto, bajo) in DEPOSITO.items():
        agregar(f'depositar_{c}_alto', alto, 'Nivel 5, reto antiguo')
        agregar(f'depositar_{c}_bajo', bajo, 'Nivel 5, reto antiguo')

    datos = {'version': 2, 'gripper': {'abierto': 100, 'cerrado': 15}, 'poses': poses}
    if os.path.exists(args.salida):
        shutil.copy(args.salida, args.salida + '.bak_g3')
        print(f'(ya existía {args.salida}; copia en {args.salida}.bak_g3)')
    with open(args.salida, 'w', encoding='utf-8') as f:
        json.dump(datos, f, indent=2, ensure_ascii=False)

    print(f'\n{"pose":24s} {"grados":38s} xyz_mm            avisos')
    malas = 0
    for n, p in poses.items():
        print(f'{n:24s} {str(p["grados"]):38s} {str(p["xyz_mm"]):18s} {"; ".join(p["avisos"]) or "ok"}')
        malas += bool(p['avisos'])
    print(f'\nGuardado en {args.salida}: {len(poses)} poses, {malas} con avisos.')
    return 1 if malas else 0


if __name__ == '__main__':
    sys.exit(main())
