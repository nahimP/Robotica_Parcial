#!/usr/bin/env python3
"""probar_moveit_g3 — prueba de IK + MoveIt2 SIN MOVER EL BRAZO.

Pide a MoveIt2 (move_group, plan_only) los planes de toda la secuencia de agarre de un color,
empezando en home, con la IK propia para los destinos cartesianos. No lee el brazo, no publica
ningún comando, no necesita el driver ni el broker: solo `move_group` (moveit_g3.launch.py).

Uso:   python3 probar_moveit_g3.py --color rojo
Salida: tabla con tiempos de IK y de MoveIt2, número de puntos, rodeo y tramos por movimiento
        + planes_moveit_g3.csv
"""
import argparse
import csv
import math
import os
import sys
import threading

import rclpy
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--color', default='rojo', choices=['rojo', 'azul', 'verde', 'amarillo'])
    ap.add_argument('--poses', default=os.path.expanduser('~/poses_g3.json'))
    ap.add_argument('--sin-mesa', action='store_true', help='no agregar la mesa a la escena de MoveIt2')
    ap.add_argument('--csv', default='planes_moveit_g3.csv')
    a = ap.parse_args()
    try:
        from arm_broker_g3 import fk, ik_g3, moveit_g3, pickplace_g3
    except Exception as e:
        sys.exit(f'No pude importar los módulos del broker ({e}). ¿source ~/rb2_ws/install/setup.bash y reconstruir?')

    poses, _ = pickplace_g3.cargar_poses(a.poses)
    obj = ik_g3.objetivos_desde_poses(poses)
    rclpy.init()
    nodo = Node('probar_moveit_g3')
    ex = MultiThreadedExecutor(num_threads=4)
    ex.add_node(nodo)
    threading.Thread(target=ex.spin, daemon=True).start()
    plan = moveit_g3.PlanificadorMoveIt(nodo, mesa_z_m=None if a.sin_mesa else -0.01)
    print('Esperando a MoveIt2 (/move_action)...')
    if not plan.esperar_servidor(15.0):
        sys.exit('MoveIt2 no responde. ¿Está corriendo "ros2 launch ~/orq_g3/moveit_g3.launch.py" en otra terminal?')
    print('MoveIt2 listo.\n')

    c = a.color
    destinos = ['ver_azul', f'recoger_{c}_alto', f'recoger_{c}_bajo', f'recoger_{c}_alto',
                f'depositar_{c}_alto', f'depositar_{c}_bajo', f'depositar_{c}_alto', 'home']
    q = [math.radians(v) for v in poses['home']]
    filas, hay_error = [], False
    print(f'{"destino":22s} {"IK ms":>6s} {"MoveIt s":>9s} {"puntos":>6s} {"tramos":>6s} {"rodeo":>6s}  resultado')
    for d in destinos:
        t_ik = 0.0
        if d in obj:
            ref = [math.radians(v) for v in obj[d]['semilla']]
            r = ik_g3.resolver(obj[d]['T'], [ref, q])
            t_ik = r['t_ms']
            if not r['ok']:
                print(f'{d:22s} IK sin solución: {r["mensaje"]}')
                hay_error = True
                break
            q_dest = r['q']
        else:
            q_dest = [math.radians(v) for v in poses[d]]
        p = plan.planificar(q, q_dest)
        if not p['ok']:
            print(f'{d:22s} {t_ik:6.1f} {"-":>9s} {"-":>6s} {"-":>6s} {"-":>6s}  FALLÓ: {p["mensaje"]}')
            hay_error = True
            break
        claves = pickplace_g3.submuestrear(p['puntos'], 0.44)
        rod = pickplace_g3.desvio(p['puntos'])
        seguro = all(fk.dentro_de_limites(x)[0] and fk.dentro_del_workspace(x)[0] for x in p['puntos'])
        veredicto = 'ok' if seguro and rod <= 2.5 else ('RODEO' if rod > 2.5 else 'FUERA DE LÍMITES')
        if veredicto != 'ok':
            hay_error = True
        print(f'{d:22s} {t_ik:6.1f} {p["t_s"]:9.3f} {len(p["puntos"]):6d} {len(claves):6d} {rod:6.2f}  {veredicto}')
        filas.append({'destino': d, 'ik_ms': round(t_ik, 1), 'moveit_s': round(p['t_s'], 3),
                      'puntos': len(p['puntos']), 'tramos': len(claves), 'rodeo': round(rod, 2),
                      'resultado': veredicto})
        q = q_dest
    if filas:
        with open(a.csv, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(filas[0]))
            w.writeheader()
            w.writerows(filas)
        print(f'\nGuardado en {a.csv}')
    print('\nTODO BIEN: MoveIt2 planificó toda la secuencia (el brazo NO se movió).' if not hay_error
          else '\nHubo problemas: copia aquí la tabla de arriba y el texto de la terminal de move_group.')
    rclpy.shutdown()


if __name__ == '__main__':
    main()
