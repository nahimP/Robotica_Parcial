#!/usr/bin/env python3
"""ensenar_ver_g3 — enseña, moviendo el brazo a mano, desde dónde mirar cada posición.

Para cada posición (azul, rojo, amarillo, verde) guarda una pose 'ver_<posicion>' en
~/poses_g3.json. Tras registrarla toma una foto y dice qué color detecta, para que sepas
si la cámara ve bien el cubo; si no, repites esa posición (r).

IMPORTANTE:
  * Antes: detener driver_g3 y el broker (este script abre /dev/ttyUSB0), y cerrar los
    kernels de Jupyter que usen la cámara.
  * Pon un cubo en la posición que vas a enseñar (el color que quieras).
  * Los motores se SUELTAN: SOSTÉN el brazo con la mano o caerá por su peso.
  * Mantén la cámara a una altura/ángulo que ENCIERRE BIEN el cubo y NO toque la mesa.

    python3 ensenar_ver_g3.py                # las 4 posiciones
    python3 ensenar_ver_g3.py --solo rojo
"""
import argparse
import json
import math
import os
import shutil
import sys
import time

import cv2

import capturar_g3 as cam
import probar_poses_g3 as mov

POSICIONES = ['azul', 'rojo', 'amarillo', 'verde']


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--solo', nargs='*', choices=POSICIONES)
    ap.add_argument('--archivo', default=os.path.expanduser('~/poses_g3.json'))
    ap.add_argument('--salida', default=os.path.expanduser('~/capturas_g3'))
    ap.add_argument('--camara', type=int, default=0)
    ap.add_argument('--area-min', type=float, default=400.0)
    ap.add_argument('--port', default='/dev/ttyUSB0')
    args = ap.parse_args(argv)

    try:
        from arm_broker_g3 import fk
    except Exception:
        fk = None
    datos = json.load(open(args.archivo, encoding='utf-8'))
    shutil.copy(args.archivo, args.archivo + '.bak_ver_g3')
    os.makedirs(args.salida, exist_ok=True)

    from pymycobot.mycobot import MyCobot
    mc = MyCobot(args.port, 1000000)
    time.sleep(0.5)
    print('\n*** ATENCIÓN: se van a soltar los motores. SOSTÉN el brazo con la mano. ***')
    input('Enter para soltar (Ctrl+C para cancelar): ')
    mc.release_all_servos()
    try:
        for pos in (args.solo or POSICIONES):
            while True:
                print(f'\n== ver_{pos}: lleva el brazo a mano hasta que la cámara vea el cubo de la posición {pos}')
                r = input('   Enter = registrar y fotografiar, s = saltar, q = terminar: ').strip().lower()
                if r in ('q', 's'):
                    break
                grados = mov.leer(mc)
                if grados is None:
                    print('   No se pudo leer el brazo; reintenta.')
                    continue
                avisos = []
                if fk:
                    q = [math.radians(v) for v in grados]
                    for ok, m in (fk.dentro_de_limites(q), fk.dentro_del_workspace(q)):
                        if not ok:
                            avisos.append(m)
                    xyz = [round(v, 1) for v in fk.fk(q)]
                else:
                    xyz = None
                frame = cam.leer_frame(args.camara)
                det = cam.detectar(frame, args.area_min)
                cv2.imwrite(os.path.join(args.salida, f'ver_{pos}.jpg'), cam.marcar(frame, det))
                print(f'   Ángulos: {[round(v, 1) for v in grados]}  xyz_mm={xyz}')
                for a in avisos:
                    print('   AVISO:', a)
                if det:
                    print('   La cámara ve: ' + ', '.join(f'{c} (area {int(d["area"])})' for c, d in det.items()))
                else:
                    print('   La cámara NO detecta ningún color desde aquí.')
                g = input('   ¿Guardar esta pose? (Enter = sí, r = repetir): ').strip().lower()
                if g == 'r':
                    continue
                datos['poses'][f'ver_{pos}'] = {
                    'grados': [round(v, 2) for v in grados], 'xyz_mm': xyz,
                    'origen': 'enseñada a mano para mirar la posición (ensenar_ver_g3)',
                    'avisos': avisos, 'fecha': time.strftime('%Y-%m-%d %H:%M:%S')}
                tmp = args.archivo + '.tmp'
                json.dump(datos, open(tmp, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
                os.replace(tmp, args.archivo)
                print('   Guardada.')
                break
            if r == 'q':
                break
    except KeyboardInterrupt:
        print('\nInterrumpido.')
    finally:
        getattr(mc, 'focus_all_servos', lambda: None)()
        print('Motores activados de nuevo.')
    faltan = [p for p in POSICIONES if f'ver_{p}' not in datos['poses']]
    print(f'\nPoses ver_* guardadas. Faltan: {faltan or "ninguna"}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
