"""moveit_g3.launch.py — `move_group` de MoveIt2 SOLO PARA PLANIFICAR (grupo 3).

Usa la configuración del paquete jetcobot_moveit (URDF, SRDF, cinemática), pero:
  * allow_trajectory_execution = False  -> MoveIt2 no puede mandar nada al brazo.
  * No arranca ros2_control ni controladores (a diferencia de demo.launch.py).
  * Pone límites de velocidad/aceleración (el paquete original los trae desactivados).
Quien mueve el brazo es únicamente el worker del broker (regla del RB-2).

Uso:  ros2 launch ~/orq_g3/moveit_g3.launch.py
"""
from launch import LaunchDescription
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    cfg = MoveItConfigsBuilder('jetcobot', package_name='jetcobot_moveit').to_moveit_configs()

    # El yaml original trae "max_velocity: 0" (entero) y MoveIt2 lo exige double: se reemplaza
    # la sección completa por una con límites reales, todos en float.
    cfg.joint_limits = {'robot_description_planning': {
        'default_velocity_scaling_factor': 0.5,
        'default_acceleration_scaling_factor': 0.5,
        'joint_limits': {
            f'{i}_Joint': {'has_velocity_limits': True, 'max_velocity': 1.5,
                           'has_acceleration_limits': True, 'max_acceleration': 3.0}
            for i in range(1, 7)}}}

    solo_planificar = {
        'allow_trajectory_execution': False,
        'moveit_manage_controllers': False,
        'publish_robot_description_semantic': True,
        'capabilities': '',
        'disable_capabilities': '',
        'publish_planning_scene': True,
        'publish_geometry_updates': True,
        'publish_state_updates': True,
        'publish_transforms_updates': True,
        'monitor_dynamics': False,
    }

    return LaunchDescription([
        Node(package='moveit_ros_move_group', executable='move_group', output='screen',
             parameters=[cfg.to_dict(), solo_planificar]),
    ])
