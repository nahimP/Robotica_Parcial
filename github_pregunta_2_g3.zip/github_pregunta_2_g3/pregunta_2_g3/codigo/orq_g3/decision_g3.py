"""Reglas puras (sin ROS) para decidir si una decisión de la Pregunta 1 puede encolarse."""

COLORES_VALIDOS = ('rojo', 'azul', 'verde', 'amarillo')


def validar_decision(d):
    """d: objeto con accion, objeto, color, permitido, motivo, prioridad.

    Devuelve (ok, causa, objeto_normalizado). Se rechaza ANTES de encolar.
    """
    if not d.permitido:
        return False, f'no permitida: {d.motivo or "rechazada por el intérprete"}', ''
    if d.accion != 'recoger':
        return False, f'acción "{d.accion}" no soportada por el agarre (solo "recoger")', ''
    if d.objeto not in ('cubo', 'cualquiera'):
        return False, f'objeto "{d.objeto}" no existe en la mesa (solo hay cubos)', ''
    if d.color not in COLORES_VALIDOS:
        return False, f'color "{d.color}" no reconocido; hay {", ".join(COLORES_VALIDOS)}', ''
    return True, '', 'cubo'
