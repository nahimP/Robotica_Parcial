from setuptools import setup

package_name = 'jetcobot_g3'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='equipo_g3',
    maintainer_email='equipo@esan.edu.pe',
    description='Driver propio G3 del JetCobot',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'driver_g3 = jetcobot_g3.driver_g3:main',
            'calibrar_g3 = jetcobot_g3.calibrar_g3:main',
        ],
    },
)
