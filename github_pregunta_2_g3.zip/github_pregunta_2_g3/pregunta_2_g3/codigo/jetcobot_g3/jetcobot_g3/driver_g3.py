"""driver_g3 — único dueño del puerto serie del JetCobot para el grupo 3.

Recibe órdenes SOLO del worker del broker (nadie más debe publicar en estos tópicos):
    /arm_g3/joint_command   (sensor_msgs/JointState, radianes, 1_Joint..6_Joint)
    /arm_g3/gripper_command (std_msgs/Int32, 0..100)
Publica el estado real:
    /arm_g3/joint_feedback y /joint_states (JointState, radianes)

dry_run=true (POR DEFECTO): no abre el puerto serie ni mueve nada; solo registra lo que
haría y devuelve como "feedback" el último comando, para probar el pipeline sin riesgo.
Para mover el brazo de verdad hay que pedirlo explícitamente: -p dry_run:=false
"""
import math
import threading
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32

from arm_broker_g3 import fk
from jetcobot_g3 import seguridad_g3 as seg


class DriverG3(Node):

    def __init__(self):
        super().__init__('driver_g3')
        self.declare_parameter('dry_run', True)
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baud', 1000000)
        self.declare_parameter('speed', 30)
        self.declare_parameter('gripper_speed', 30)
        self.declare_parameter('min_period_s', 0.05)
        self.declare_parameter('min_delta_deg', 0.5)
        self.declare_parameter('feedback_period_s', 0.5)
        self.declare_parameter('angulos_iniciales_deg', [0.0, 0.0, 0.0, 0.0, 0.0, -45.0])

        self.dry = bool(self.get_parameter('dry_run').value)
        self.speed = int(self.get_parameter('speed').value)
        self.gspeed = int(self.get_parameter('gripper_speed').value)
        self.min_period = float(self.get_parameter('min_period_s').value)
        self.min_delta = float(self.get_parameter('min_delta_deg').value)
        self.lock = threading.Lock()
        self.last_send = 0.0
        self.last_sent = None
        self.q_dry = [float(a) for a in self.get_parameter('angulos_iniciales_deg').value]
        self.mc = None

        if not self.dry:
            from pymycobot.mycobot import MyCobot
            port = self.get_parameter('port').value
            self.mc = MyCobot(port, int(self.get_parameter('baud').value))
            time.sleep(0.1)
            if self.mc.get_fresh_mode() == 0:
                self.mc.set_fresh_mode(1)
                time.sleep(0.05)

        self.pub_fb = self.create_publisher(JointState, '/arm_g3/joint_feedback', 10)
        self.pub_js = self.create_publisher(JointState, '/joint_states', 10)
        self.create_subscription(JointState, '/arm_g3/joint_command', self.on_joint, 10)
        self.create_subscription(Int32, '/arm_g3/gripper_command', self.on_gripper, 10)
        self.create_timer(float(self.get_parameter('feedback_period_s').value), self.publicar_feedback)

        modo = 'DRY_RUN (no mueve nada)' if self.dry else 'FISICO (mueve el brazo)'
        self.get_logger().warn(f'driver_g3 listo · modo={modo} · speed={self.speed}')

    def on_joint(self, msg):
        grados, motivo = seg.comando_a_grados(
            msg.name, msg.position, fk.JOINT_NAMES, fk.JOINT_LIMITS)
        if grados is None:
            self.get_logger().error(f'Comando RECHAZADO por el driver: {motivo}')
            return
        ahora = time.monotonic()
        if ahora - self.last_send < self.min_period:
            return
        if self.last_sent is not None and seg.salto_maximo_deg(grados, self.last_sent) < self.min_delta:
            return
        with self.lock:
            if self.dry:
                self.q_dry = list(grados)
                self.get_logger().info(f'[DRY_RUN] enviaría send_angles({grados}, {self.speed})')
            else:
                self.mc.send_angles(grados, self.speed)
        self.last_send, self.last_sent = ahora, grados

    def on_gripper(self, msg):
        valor = seg.limitar_valor_gripper(msg.data)
        with self.lock:
            if self.dry:
                self.get_logger().info(f'[DRY_RUN] enviaría set_gripper_value({valor}, {self.gspeed})')
            else:
                self.mc.set_gripper_value(valor, self.gspeed)

    def publicar_feedback(self):
        with self.lock:
            if self.dry:
                grados = list(self.q_dry)
            else:
                try:
                    grados = self.mc.get_angles()
                except Exception as e:
                    self.get_logger().error(f'Error leyendo articulaciones: {e}')
                    return
        if (not isinstance(grados, (list, tuple)) or len(grados) != 6
                or not all(isinstance(a, (int, float)) and math.isfinite(a) for a in grados)):
            self.get_logger().warn('Lectura articular inválida; no se publica')
            return
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = list(fk.JOINT_NAMES)
        msg.position = [math.radians(float(a)) for a in grados]
        self.pub_fb.publish(msg)
        self.pub_js.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    nodo = DriverG3()
    try:
        rclpy.spin(nodo)
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
