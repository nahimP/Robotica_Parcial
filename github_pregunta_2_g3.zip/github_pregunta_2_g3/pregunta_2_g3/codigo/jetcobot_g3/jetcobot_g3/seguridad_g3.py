"""Validación pura (sin ROS ni hardware) de los comandos que recibe el driver G3."""
import math


def comando_a_grados(nombres, posiciones, orden, limites_rad):
    """Convierte un JointState (radianes) a lista de 6 grados, o rechaza.

    Devuelve (grados | None, motivo). Rechaza si falta una articulación, hay valores
    no finitos o alguno excede los límites de los motores.
    """
    por_nombre = dict(zip(nombres, posiciones))
    q = []
    for n in orden:
        if n not in por_nombre:
            return None, f'falta la articulación {n}'
        v = float(por_nombre[n])
        if not math.isfinite(v):
            return None, f'valor no finito en {n}'
        q.append(v)
    for n, v, (lo, hi) in zip(orden, q, limites_rad):
        if not lo <= v <= hi:
            return None, f'{n} fuera de límites: {v:.3f} rad, permitido [{lo}, {hi}]'
    return [round(math.degrees(v), 3) for v in q], ''


def salto_maximo_deg(a, b):
    return max(abs(x - y) for x, y in zip(a, b))


def limitar_valor_gripper(valor, minimo=0, maximo=100):
    v = int(round(float(valor)))
    return max(minimo, min(maximo, v))
