#!/usr/bin/env python3
"""calibrar_g3 — registra las poses PROPIAS del grupo 3 (medidas en su mesa).

Lee los ángulos reales del brazo con pymycobot y los guarda en poses_g3.json
junto con su posición cartesiana (FK del RB-2). NO manda movimientos.

IMPORTANTE:
  * Detener antes driver_g3 y cualquier otro programa que use el puerto serie.
  * Con --soltar se sueltan los motores para posicionar el brazo a mano: SOSTENER
    el brazo con la otra mano, porque caería por su peso.

Uso:
    ros2 run jetcobot_g3 calibrar_g3 --soltar
    ros2 run jetcobot_g3 calibrar_g3 --solo home inspeccion
"""
import argparse
import json
import math
import os
import sys
import time

POSES_DEFECTO = [
    ('home',        'posición de reposo / inicio del brazo'),
    ('inspeccion',  'desde donde la cámara ve los 4 objetos'),
    ('segura',      'pose elevada y segura para trasladarse'),
    ('slot_1_alto', 'sobre el objeto del lugar 1, sin tocarlo'),
    ('slot_1_bajo', 'lugar 1, pinza lista para cerrar sobre el objeto'),
    ('slot_2_alto', 'sobre el objeto del lugar 2'),
    ('slot_2_bajo', 'lugar 2, pinza lista para cerrar'),
    ('slot_3_alto', 'sobre el objeto del lugar 3'),
    ('slot_3_bajo', 'lugar 3, pinza lista para cerrar'),
    ('slot_4_alto', 'sobre el objeto del lugar 4'),
    ('slot_4_bajo', 'lugar 4, pinza lista para cerrar'),
    ('zona_alto',   'sobre la zona de depósito'),
    ('zona_bajo',   'zona de depósito, a la altura de soltar'),
]


def leer_angulos(mc, intentos=5):
    """Devuelve 6 grados válidos o None."""
    for _ in range(intentos):
        a = mc.get_angles()
        if (isinstance(a, (list, tuple)) and len(a) == 6
                and all(isinstance(v, (int, float)) and math.isfinite(v) for v in a)):
            return [round(float(v), 2) for v in a]
        time.sleep(0.2)
    return None


def evaluar_pose(grados, fk=None):
    """Devuelve (xyz_mm | None, avisos). Usa el fk.py del RB-2 si está disponible."""
    if fk is None:
        return None, ['sin fk.py: no se validó límites/workspace']
    q = [math.radians(v) for v in grados]
    avisos = []
    ok, msg = fk.dentro_de_limites(q)
    if not ok:
        avisos.append(f'LÍMITES: {msg}')
    ok, msg = fk.dentro_del_workspace(q)
    if not ok:
        avisos.append(f'WORKSPACE: {msg}')
    x, y, z = fk.fk(q)
    return [round(x, 1), round(y, 1), round(z, 1)], avisos


def guardar(ruta, datos):
    tmp = ruta + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(datos, f, indent=2, ensure_ascii=False)
    os.replace(tmp, ruta)


def cargar(ruta):
    if os.path.exists(ruta):
        with open(ruta, encoding='utf-8') as f:
            return json.load(f)
    return {'version': 1, 'gripper': {'abierto': 100, 'cerrado': 15}, 'poses': {}}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', default='/dev/ttyUSB0')
    ap.add_argument('--baud', type=int, default=1000000)
    ap.add_argument('--salida', default=os.path.expanduser('~/poses_g3.json'))
    ap.add_argument('--soltar', action='store_true', help='soltar motores para mover a mano')
    ap.add_argument('--solo', nargs='*', help='registrar solo estas poses (nombres)')
    args = ap.parse_args(argv)

    try:
        from arm_broker_g3 import fk
    except Exception:
        fk = None

    from pymycobot.mycobot import MyCobot
    mc = MyCobot(args.port, args.baud)
    time.sleep(0.5)

    datos = cargar(args.salida)
    lista = [p for p in POSES_DEFECTO if not args.solo or p[0] in args.solo]
    soltado = False
    try:
        if args.soltar:
            print('\n*** ATENCIÓN: se van a soltar los motores. SOSTÉN el brazo con la mano. ***')
            input('Enter para soltar (Ctrl+C para cancelar): ')
            mc.release_all_servos()
            soltado = True
        for nombre, descripcion in lista:
            previo = ' (ya registrada; se sobrescribe)' if nombre in datos['poses'] else ''
            print(f'\n== {nombre}: {descripcion}{previo}')
            r = input('Coloca el brazo y pulsa Enter para registrar [s = saltar, q = terminar]: ').strip().lower()
            if r == 'q':
                break
            if r == 's':
                continue
            grados = leer_angulos(mc)
            if grados is None:
                print('  No se pudo leer el brazo; se omite esta pose.')
                continue
            xyz, avisos = evaluar_pose(grados, fk)
            for a in avisos:
                print('  AVISO:', a)
            datos['poses'][nombre] = {
                'grados': grados, 'xyz_mm': xyz,
                'fecha': time.strftime('%Y-%m-%d %H:%M:%S'),
                'avisos': avisos,
            }
            guardar(args.salida, datos)
            print(f'  Registrada: {grados}  xyz_mm={xyz}')
    except KeyboardInterrupt:
        print('\nInterrumpido.')
    finally:
        if soltado:
            getattr(mc, 'focus_all_servos', lambda: None)()
            print('Motores activados de nuevo.')
    faltan = [n for n, _ in POSES_DEFECTO if n not in datos['poses']]
    print(f'\nGuardado en {args.salida}. Poses registradas: {len(datos["poses"])}. Faltan: {faltan or "ninguna"}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
