"""ik_g3 — cinemática inversa del JetCobot (MyCobot 280) sobre el MISMO modelo DH del RB-2.

Resuelve  T_objetivo (4x4, mm) -> q (rad)  con mínimos cuadrados amortiguados (Levenberg–
Marquardt) sobre la posición y la orientación, usando el Jacobiano geométrico del modelo
DH de fk.py. Como usa la misma tabla DH que la cinemática directa del RB-2, el error que se
reporta (FK de lo pedido vs FK de lo leído) es coherente con el modelo que resolvió la IK.

Es lógica PURA (solo numpy): se prueba sin ROS y sin brazo.

Objetivos cartesianos (calibración): las posiciones de los cubos y de las zonas son
"conocidas" (enunciado). Se calibran UNA vez midiendo las poses articulares de referencia
con la FK (poses_g3.json) -> objetivos_desde_poses(). A partir de ahí el movimiento se pide
en cartesianas (x, y, z, orientación) y esta IK entrega los ángulos.
"""
import math
import time

import numpy as np

from arm_broker_g3 import fk

# Límites del URDF de MoveIt (jetcobot.urdf): ±1.57 en J2, J3, J4, J6; ±3.05 en J1 y J5.
LIM_URDF = (3.05, 1.57, 1.57, 1.57, 3.05, 1.57)
MARGEN_RAD = 0.03

# Peso de la orientación frente a la posición (metros por radián): 0.15 m ~ brazo de palanca.
PESO_ORIENTACION = 0.15


def limites():
    """(lo, hi) por articulación: la intersección de los límites del RB-2 y del URDF."""
    lo, hi = [], []
    for (a, b), u in zip(fk.JOINT_LIMITS, LIM_URDF):
        u -= MARGEN_RAD
        lo.append(max(a, -u))
        hi.append(min(b, u))
    return np.array(lo), np.array(hi)


# ------------------------------------------------------------------ cinemática (numpy)
def _dh(alpha, a, d, theta):
    ca, sa, ct, st = math.cos(alpha), math.sin(alpha), math.cos(theta), math.sin(theta)
    return np.array([[ct, -st * ca, st * sa, a * ct],
                     [st, ct * ca, -ct * sa, a * st],
                     [0.0, sa, ca, d],
                     [0.0, 0.0, 0.0, 1.0]])


def cadena(q):
    """Lista de 7 transformaciones acumuladas T_0 (identidad) ... T_6 (efector)."""
    Ts = [np.eye(4)]
    for (alpha, a, d, off), th in zip(fk.DH, q):
        Ts.append(Ts[-1] @ _dh(alpha, a, d, th + off))
    return Ts


def fk_T(q):
    return cadena(q)[-1]


def jacobiano(q):
    """Jacobiano geométrico 6x6 (filas: v en mm, w en rad) en el marco base."""
    Ts = cadena(q)
    pe = Ts[-1][:3, 3]
    J = np.zeros((6, 6))
    for i in range(6):
        z = Ts[i][:3, 2]
        p = Ts[i][:3, 3]
        J[:3, i] = np.cross(z, pe - p)
        J[3:, i] = z
    return J


def rotvec(R):
    """Vector de rotación (eje*ángulo) de una matriz de rotación."""
    c = max(-1.0, min(1.0, (np.trace(R) - 1.0) / 2.0))
    ang = math.acos(c)
    if ang < 1e-10:
        return np.zeros(3)
    if math.pi - ang < 1e-6:
        M = (R + np.eye(3)) / 2.0
        k = int(np.argmax(np.diag(M)))
        eje = M[:, k] / math.sqrt(max(M[k, k], 1e-12))
        return eje / np.linalg.norm(eje) * ang
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]]) / (2.0 * math.sin(ang))
    return v * ang


def error_pose(T_obj, T_act):
    """(e_pos mm, e_ori rad) de T_act respecto a T_obj, ambos en el marco base."""
    return T_obj[:3, 3] - T_act[:3, 3], rotvec(T_obj[:3, :3] @ T_act[:3, :3].T)


# ------------------------------------------------------------------ IK
def _resolver_una(T_obj, q0, lo, hi, tol_mm, tol_rad, max_iter, w=PESO_ORIENTACION):
    q = np.clip(np.array(q0, float), lo, hi)
    lam = 0.05
    mejor = None
    for it in range(max_iter):
        T = fk_T(q)
        ep, eo = error_pose(T_obj, T)
        n_p, n_o = float(np.linalg.norm(ep)), float(np.linalg.norm(eo))
        costo = n_p / 1000.0 + w * n_o
        if mejor is None or costo < mejor[0]:
            mejor = (costo, q.copy(), n_p, n_o, it)
        if n_p <= tol_mm and n_o <= tol_rad:
            return True, q, n_p, n_o, it
        J = jacobiano(q)
        J[:3] /= 1000.0                               # m
        J[3:] *= w                                    # radianes ponderados
        e = np.concatenate([ep / 1000.0, w * eo])
        A = J @ J.T + (lam ** 2) * np.eye(6)
        dq = J.T @ np.linalg.solve(A, e)
        m = float(np.max(np.abs(dq)))
        if m > 0.2:
            dq *= 0.2 / m
        q = np.clip(q + dq, lo, hi)
    return False, mejor[1], mejor[2], mejor[3], mejor[4]


def resolver(T_obj, semillas, tol_mm=0.05, tol_rad=0.0005, max_iter=300, extra=6, peso_ori=PESO_ORIENTACION):
    """IK de T_obj. `semillas` = lista de q (rad); la PRIMERA es la de referencia (rama deseada).

    Entre todas las soluciones que convergen devuelve la más cercana a la primera semilla
    (movimientos cortos, misma rama del codo). Si ninguna converge, ok=False.

    Devuelve dict: ok, q (rad), err_pos_mm, err_ori_rad, iteraciones, t_ms, mensaje.
    """
    t0 = time.perf_counter()
    lo, hi = limites()
    ref = np.array(semillas[0], float)
    lista = [np.array(s, float) for s in semillas]
    rng = np.random.default_rng(12345)
    mejores = []
    fallo = None
    for k in range(len(lista) + extra):
        if k < len(lista):
            q0 = lista[k]
        else:
            if mejores:
                break                                  # ya hay solución: no hace falta explorar
            q0 = np.clip(ref + rng.normal(0.0, 0.35, 6), lo, hi)
        ok, q, n_p, n_o, it = _resolver_una(T_obj, q0, lo, hi, tol_mm, tol_rad, max_iter, peso_ori)
        if ok:
            mejores.append((float(np.max(np.abs(q - ref))), q, n_p, n_o, it))
        elif fallo is None or (n_p + 100 * n_o) < (fallo[2] + 100 * fallo[3]):
            fallo = (q, q, n_p, n_o, it)
    t_ms = (time.perf_counter() - t0) * 1000.0
    if mejores:
        _, q, n_p, n_o, it = min(mejores, key=lambda r: r[0])
        return {'ok': True, 'q': [float(v) for v in q], 'err_pos_mm': n_p, 'err_ori_rad': n_o,
                'iteraciones': it, 't_ms': t_ms, 'mensaje': 'IK convergió'}
    q, _, n_p, n_o, it = fallo
    return {'ok': False, 'q': [float(v) for v in q], 'err_pos_mm': n_p, 'err_ori_rad': n_o,
            'iteraciones': it, 't_ms': t_ms,
            'mensaje': f'IK sin solución (mejor intento: {n_p:.1f} mm, {math.degrees(n_o):.1f}°)'}


# ------------------------------------------------------------------ objetivos cartesianos
def T_desde_grados(q_deg):
    return fk_T([math.radians(v) for v in q_deg])


def objetivos_desde_poses(poses):
    """Tabla de objetivos cartesianos {nombre: {'T': 4x4, 'semilla': q_deg}} a partir de las
    poses de referencia medidas (calibración con la FK del RB-2).

    Los cubos y las zonas están en posiciones CONOCIDAS (enunciado). Se calibran una vez: la
    FK del RB-2 convierte cada pose medida (recoger_<c>_alto/bajo, depositar_<c>_alto/bajo)
    en un objetivo cartesiano (x, y, z, orientación). En ejecución el sistema pide ese objetivo
    cartesiano y la IK entrega los ángulos. La semilla de cada IK es la pose enseñada (elige la
    rama del codo: no puede saltar a otra configuración del brazo).

    Nota: se probó 'bajo + 70 mm en Z con la misma orientación' como aproximación; para los
    cubos lejanos (amarillo y verde, a ~280 mm de la base) esa pose NO tiene solución con la
    pinza vertical (límite de alcance), por eso la aproximación es la pose 'alto' calibrada.
    """
    obj = {}
    for nombre, grados in poses.items():
        if nombre.startswith(('recoger_', 'depositar_')) and nombre.endswith(('_alto', '_bajo')):
            obj[nombre] = {'T': T_desde_grados(grados), 'semilla': list(grados)}
    return obj
