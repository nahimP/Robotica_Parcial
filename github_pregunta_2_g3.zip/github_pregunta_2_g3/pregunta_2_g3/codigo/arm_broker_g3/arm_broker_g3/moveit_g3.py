"""moveit_g3 — cliente de MoveIt2 SOLO PARA PLANIFICAR (plan_only).

El broker le pide a `move_group` (acción /move_action) una trayectoria libre de colisión entre
dos configuraciones articulares y recibe los puntos. MoveIt2 NUNCA ejecuta: no hay controlador
conectado al brazo y la solicitud va con plan_only=True. Quien publica el comando al brazo sigue
siendo únicamente el worker del broker (regla del RB-2).

Hace falta moveit_msgs (viene con MoveIt2) y un `move_group` en marcha (moveit_g3.launch.py).
"""
import math
import threading
import time

from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup

from geometry_msgs.msg import Pose
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import (CollisionObject, Constraints, JointConstraint, MotionPlanRequest,
                             PlanningOptions)
from shape_msgs.msg import SolidPrimitive

from arm_broker_g3 import fk, ik_g3

CODIGOS = {1: 'SUCCESS', -1: 'FAILURE', -2: 'PLANNING_FAILED', -3: 'INVALID_MOTION_PLAN',
           -7: 'TIMED_OUT', -10: 'START_STATE_IN_COLLISION', -12: 'GOAL_IN_COLLISION',
           -14: 'GOAL_CONSTRAINTS_VIOLATED', -15: 'INVALID_GROUP_NAME',
           -16: 'INVALID_GOAL_CONSTRAINTS', -17: 'INVALID_ROBOT_STATE',
           -21: 'FRAME_TRANSFORM_FAILURE', -23: 'ROBOT_STATE_STALE', -31: 'NO_IK_SOLUTION'}


def _fallo(mensaje, t0, **extra):
    d = {'ok': False, 'puntos': [], 't_s': time.perf_counter() - t0, 't_moveit_s': 0.0,
         'mensaje': mensaje}
    d.update(extra)
    return d


class PlanificadorMoveIt:
    def __init__(self, nodo, grupo='arm_group', accion='/move_action', tiempo_plan_s=3.0,
                 intentos=5, vel=0.5, acel=0.5, mesa_z_m=-0.01, planner_id='', pipeline_id='',
                 timeout_s=20.0):
        self.nodo, self.grupo = nodo, grupo
        self.tiempo_plan_s, self.intentos = float(tiempo_plan_s), int(intentos)
        self.vel, self.acel = float(vel), float(acel)
        self.mesa_z_m = mesa_z_m
        self.planner_id, self.pipeline_id = planner_id, pipeline_id
        self.timeout_s = float(timeout_s)
        self.cli = ActionClient(nodo, MoveGroup, accion, callback_group=ReentrantCallbackGroup())

    # ------------------------------------------------------------ disponibilidad
    def disponible(self):
        return self.cli.server_is_ready()

    def esperar_servidor(self, timeout_s=10.0):
        return self.cli.wait_for_server(timeout_sec=timeout_s)

    # ------------------------------------------------------------ solicitud
    def _estado(self, q):
        """RobotState con q (rad), recortado a los límites del URDF (MoveIt rechaza lo que se pasa)."""
        from moveit_msgs.msg import RobotState
        rs = RobotState()
        rs.joint_state.name = list(fk.JOINT_NAMES)
        rs.joint_state.position = [
            max(-(u - 0.001), min(u - 0.001, float(v))) for v, u in zip(q, ik_g3.LIM_URDF)]
        return rs

    def _escena(self):
        po = PlanningOptions()
        po.plan_only = True                    # MoveIt2 planifica; NO ejecuta
        po.planning_scene_diff.is_diff = True
        po.planning_scene_diff.robot_state.is_diff = True
        if self.mesa_z_m is not None:
            o = CollisionObject()
            o.header.frame_id = 'base_link'
            o.id = 'mesa_g3'
            caja = SolidPrimitive()
            caja.type = SolidPrimitive.BOX
            caja.dimensions = [1.2, 1.2, 0.02]
            pose = Pose()
            pose.position.x = 0.15
            pose.position.z = float(self.mesa_z_m) - 0.01     # cara superior en mesa_z_m
            pose.orientation.w = 1.0
            o.primitives.append(caja)
            o.primitive_poses.append(pose)
            o.operation = CollisionObject.ADD
            po.planning_scene_diff.world.collision_objects.append(o)
        return po

    def _goal(self, q_ini, q_fin):
        req = MotionPlanRequest()
        req.group_name = self.grupo
        req.num_planning_attempts = self.intentos
        req.allowed_planning_time = self.tiempo_plan_s
        req.max_velocity_scaling_factor = self.vel
        req.max_acceleration_scaling_factor = self.acel
        if self.planner_id and hasattr(req, 'planner_id'):
            req.planner_id = self.planner_id
        if self.pipeline_id and hasattr(req, 'pipeline_id'):
            req.pipeline_id = self.pipeline_id
        req.start_state = self._estado(q_ini)
        c = Constraints()
        for nombre, v, u in zip(fk.JOINT_NAMES, q_fin, ik_g3.LIM_URDF):
            jc = JointConstraint()
            jc.joint_name = nombre
            jc.position = max(-(u - 0.001), min(u - 0.001, float(v)))
            jc.tolerance_above = jc.tolerance_below = 0.001
            jc.weight = 1.0
            c.joint_constraints.append(jc)
        req.goal_constraints.append(c)
        goal = MoveGroup.Goal()
        goal.request = req
        goal.planning_options = self._escena()
        return goal

    @staticmethod
    def _esperar(future, timeout_s, cancelado):
        ev = threading.Event()
        future.add_done_callback(lambda _: ev.set())
        fin = time.monotonic() + timeout_s
        while time.monotonic() < fin:
            if ev.wait(0.1):
                return future.done()
            if cancelado():
                return False
        return False

    # ------------------------------------------------------------ planificar
    def planificar(self, q_ini, q_fin, cancelado=lambda: False):
        """Devuelve {'ok', 'puntos' [[rad]*6, ...] (el primero = q_ini), 't_s' (reloj de pared),
        't_moveit_s' (tiempo que dice MoveIt2), 'mensaje'}."""
        t0 = time.perf_counter()
        if max(abs(a - b) for a, b in zip(q_ini, q_fin)) < 0.01:      # ya está ahí
            return {'ok': True, 'puntos': [list(q_ini), list(q_fin)], 't_s': 0.0,
                    't_moveit_s': 0.0, 'mensaje': 'ya en el destino'}
        if not self.disponible():
            return _fallo('MoveIt2 no disponible: ¿está corriendo moveit_g3.launch.py?', t0)
        fut = self.cli.send_goal_async(self._goal(q_ini, q_fin))
        if not self._esperar(fut, 5.0, cancelado):
            return _fallo('move_group no respondió a la solicitud', t0)
        gh = fut.result()
        if not gh.accepted:
            return _fallo('move_group rechazó la solicitud', t0)
        rf = gh.get_result_async()
        if not self._esperar(rf, self.timeout_s, cancelado):
            gh.cancel_goal_async()
            return _fallo('MoveIt2 no terminó de planificar a tiempo (o se canceló)', t0)
        r = rf.result().result
        codigo = int(r.error_code.val)
        if codigo != 1:
            return _fallo(f'MoveIt2 no encontró plan: {CODIGOS.get(codigo, codigo)}', t0,
                          t_moveit_s=float(r.planning_time))
        jt = r.planned_trajectory.joint_trajectory
        try:
            idx = [list(jt.joint_names).index(n) for n in fk.JOINT_NAMES]
        except ValueError:
            return _fallo(f'la trayectoria de MoveIt2 no trae las articulaciones esperadas: {list(jt.joint_names)}', t0)
        puntos = [[float(p.positions[i]) for i in idx] for p in jt.points]
        if len(puntos) < 2:
            puntos = [list(q_ini), list(q_fin)]
        return {'ok': True, 'puntos': puntos, 't_s': time.perf_counter() - t0,
                't_moveit_s': float(r.planning_time), 'mensaje': 'plan encontrado'}
