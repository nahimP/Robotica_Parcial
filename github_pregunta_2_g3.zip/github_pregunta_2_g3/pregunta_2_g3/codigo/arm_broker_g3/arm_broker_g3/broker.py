"""arm_broker_g3 — el único nodo que publica comandos al brazo (/arm_g3/joint_command).

Andamiaje entregado por el curso. Los bloques IMPLEMENTAR son lo que evalúa el
reto; el resto es instrumentación y se usa tal cual.
"""

import csv
import os
import threading
import time
import math

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32

from arm_broker_interfaces_g3.action import MoveArm, PickPlace
from arm_broker_interfaces_g3.msg import QueueState

from arm_broker_g3 import fk
from arm_broker_g3 import pickplace_g3
from arm_broker_g3.politicas import POLITICAS, Pedido


class ArmBroker(Node):

    def __init__(self):
        super().__init__('arm_broker_g3')

        self.declare_parameter('politica', 'fifo')
        self.declare_parameter('modo_simulacion', True)
        self.declare_parameter('angulos_iniciales_deg', [0.0, 0.0, 0.0, 0.0, 0.0, -45.0])
        self.declare_parameter('tau_envejecimiento_s', 8.0)
        self.declare_parameter('cola_max', 20)
        self.declare_parameter('paso_max_rad', 1.2)
        self.declare_parameter('duracion_movimiento_s', 3.0)
        self.declare_parameter('pasos_interpolacion', 10)
        # --- Pregunta 2: agarre físico (solo si pick_place_real=true y modo_simulacion=false)
        self.declare_parameter('pick_place_real', False)
        self.declare_parameter('poses_archivo', '~/poses_g3.json')
        self.declare_parameter('tramo_max_rad', 0.44)
        self.declare_parameter('tol_llegada_deg', 3.0)
        self.declare_parameter('timeout_tramo_s', 12.0)
        self.declare_parameter('pausa_pinza_s', 1.5)
        # --- Visión: antes de recoger, mirar las 4 posiciones con la cámara (sobre la pinza)
        self.declare_parameter('usar_vision', False)
        self.declare_parameter('area_ok_px', 8000.0)
        self.declare_parameter('camara', 0)
        self.declare_parameter('carpeta_capturas', '~/capturas_g3')
        # --- Cadena completa: IK propia + MoveIt2 (solo planifica). Requieren pick_place_real=true
        self.declare_parameter('usar_ik', False)
        self.declare_parameter('usar_moveit', False)
        self.declare_parameter('moveit_accion', '/move_action')
        self.declare_parameter('moveit_tiempo_s', 3.0)
        self.declare_parameter('moveit_intentos', 5)
        self.declare_parameter('moveit_vel', 0.5)
        self.declare_parameter('usar_mesa', True)
        self.declare_parameter('mesa_z_m', -0.01)
        self.declare_parameter('desvio_max', 2.5)
        self.declare_parameter('ik_desv_max_deg', 20.0)
        self.declare_parameter('tiempos_csv', '~/tiempos_pickplace_g3.csv')

        nombre = self.get_parameter('politica').value
        if nombre not in POLITICAS:
            raise RuntimeError(f'política desconocida: {nombre}. Hay {list(POLITICAS)}')
        clase = POLITICAS[nombre]
        if nombre == 'prioridad':
            self.politica = clase(self.get_parameter('tau_envejecimiento_s').value)
        else:
            self.politica = clase()

        self.modo_simulacion = bool(self.get_parameter('modo_simulacion').value)
        self.cola_max = int(self.get_parameter('cola_max').value)
        self.paso_max = float(self.get_parameter('paso_max_rad').value)
        self.duracion = float(self.get_parameter('duracion_movimiento_s').value)
        self.pasos = max(1, int(self.get_parameter('pasos_interpolacion').value))
        self.pick_place_real = bool(self.get_parameter('pick_place_real').value)
        self.poses_archivo = self.get_parameter('poses_archivo').value
        self.tramo_max = float(self.get_parameter('tramo_max_rad').value)
        self.tol_llegada = math.radians(float(self.get_parameter('tol_llegada_deg').value))
        self.timeout_tramo = float(self.get_parameter('timeout_tramo_s').value)
        self.pausa_pinza = float(self.get_parameter('pausa_pinza_s').value)
        self.usar_vision = bool(self.get_parameter('usar_vision').value)
        self.area_ok = float(self.get_parameter('area_ok_px').value)
        self.camara = int(self.get_parameter('camara').value)
        self.carpeta_capturas = os.path.expanduser(self.get_parameter('carpeta_capturas').value)
        self.cap = None
        self.usar_ik = bool(self.get_parameter('usar_ik').value)
        self.usar_moveit = bool(self.get_parameter('usar_moveit').value)
        self.desvio_max = float(self.get_parameter('desvio_max').value)
        self.ik_desv_max = float(self.get_parameter('ik_desv_max_deg').value)
        self.tiempos_csv = os.path.expanduser(self.get_parameter('tiempos_csv').value)
        self.objetivos, self.planificador = {}, None
        self.poses, self.gripper = {}, {'abierto': 100, 'cerrado': 15}
        if self.pick_place_real and self.usar_vision:
            from arm_broker_g3 import capturar_g3   # exige OpenCV; solo si se pide visión
            self.cap = capturar_g3
            os.makedirs(self.carpeta_capturas, exist_ok=True)
        if self.pick_place_real:
            if self.modo_simulacion:
                raise RuntimeError('pick_place_real=true exige modo_simulacion=false')
            self.poses, self.gripper = pickplace_g3.cargar_poses(self.poses_archivo)
            self.get_logger().warn(
                f'PickPlace FISICO activo · {len(self.poses)} poses de {self.poses_archivo}')
        elif self.usar_ik or self.usar_moveit:
            raise RuntimeError('usar_ik / usar_moveit exigen pick_place_real=true')

        self.grupo_entrada = ReentrantCallbackGroup()
        self.grupo_worker = MutuallyExclusiveCallbackGroup()

        self.lock = threading.Lock()
        self.pendientes = []
        self.por_goal_id = {}
        self.ejecutando = None
        grados_ini = list(self.get_parameter('angulos_iniciales_deg').value)
        if not self.modo_simulacion:
            if len(grados_ini) != 6 or not all(
                math.isfinite(float(a)) for a in grados_ini
            ):
                raise RuntimeError(
                    'Modo fisico requiere seis angulos_iniciales_deg reales'
                )
        self.ultima_lectura_real = 0.0
        self.q_real_disponible = False
        self.q_actual = (
            [math.radians(float(a)) for a in grados_ini]
            if len(grados_ini) == 6 else [0.0] * 6
        )
        self.n_aceptados = 0
        self.n_rechazados = 0
        self.n_completados = 0
        self._parar = threading.Event()

        self.pub_joint = self.create_publisher(JointState, '/arm_g3/joint_command', 10)
        self.pub_cola = self.create_publisher(QueueState, '/arm_g3/queue_state', 10)
        self.pub_pinza = self.create_publisher(Int32, '/arm_g3/gripper_command', 10)
        self.sub_real = self.create_subscription(
            JointState, '/arm_g3/joint_feedback',
            self.recibir_posicion_real, 10
        )

        if self.pick_place_real and self.usar_ik:
            from arm_broker_g3 import ik_g3
            self.ik_g3 = ik_g3
            self.objetivos = ik_g3.objetivos_desde_poses(self.poses)
            self.get_logger().info(
                f'IK propia activa · {len(self.objetivos)} objetivos cartesianos calibrados con la FK del RB-2')
        if self.pick_place_real and self.usar_moveit:
            from arm_broker_g3 import moveit_g3
            mesa = float(self.get_parameter('mesa_z_m').value) if self.get_parameter('usar_mesa').value else None
            self.planificador = moveit_g3.PlanificadorMoveIt(
                self, accion=self.get_parameter('moveit_accion').value,
                tiempo_plan_s=self.get_parameter('moveit_tiempo_s').value,
                intentos=self.get_parameter('moveit_intentos').value,
                vel=self.get_parameter('moveit_vel').value, mesa_z_m=mesa)
            self.get_logger().info('MoveIt2 como planificador (plan_only): el broker ejecuta, MoveIt2 no')

        self.servidor = ActionServer(
            self,
            MoveArm,
            'move_arm_g3',
            goal_callback=self.goal_callback,
            handle_accepted_callback=self.handle_accepted_callback,
            cancel_callback=self.cancel_callback,
            execute_callback=self.execute_callback,
            callback_group=self.grupo_entrada,
        )

        self.servidor_pick = ActionServer(
            self,
            PickPlace,
            'pick_place_g3',
            goal_callback=self.pick_place_goal_callback,
            handle_accepted_callback=self.pick_place_accepted_callback,
            cancel_callback=self.cancel_callback,
            execute_callback=self.pick_place_execute_callback,
            callback_group=self.grupo_entrada,
        )

        self.create_timer(0.2, self.publicar_estado_cola,
                          callback_group=self.grupo_worker)

        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

        self.get_logger().info(
            f'arm_broker_g3 listo · política={self.politica.nombre} · '
            f'cola_max={self.cola_max} · único publicador de comandos al brazo')

    # ========================= IMPLEMENTAR · ítem 2 ==========================
    def goal_callback(self, goal_request):
        """Admisión. Barata e inmediata: acepta o rechaza, nunca ejecuta."""
        q_dest = list(goal_request.joint_positions)
        quien = goal_request.client_id

        # Sin una lectura real reciente, no se admiten órdenes físicas.
        if not self.modo_simulacion:
            reciente, _ = self.posicion_real_reciente()
            if not reciente:
                self.get_logger().error('Rechazo: sin lectura articular reciente')
                return GoalResponse.REJECT

        # 1. ¿Está dentro de los límites de los motores?
        ok_limites, msg_limites = fk.dentro_de_limites(q_dest)
        if not ok_limites:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().info(f'Rechazo [{quien}]: {msg_limites}')
            return GoalResponse.REJECT

        # 2. ¿Chocará con la mesa o su propia base (workspace)?
        ok_ws, msg_ws = fk.dentro_del_workspace(q_dest)
        if not ok_ws:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().info(f'Rechazo [{quien}]: {msg_ws}')
            return GoalResponse.REJECT

        # 3. ¿El movimiento es demasiado brusco desde donde está ahora?
        with self.lock:
            q_act = list(self.q_actual)
        paso = fk.paso_articular(q_act, q_dest)
        if paso > self.paso_max:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().info(
                f'Rechazo [{quien}]: paso articular {paso:.2f} rad '
                f'excede el máximo {self.paso_max:.2f} rad')
            return GoalResponse.REJECT

        with self.lock:
            self.n_aceptados += 1
        return GoalResponse.ACCEPT

    def handle_accepted_callback(self, goal_handle):
        """Encolar. AQUÍ NO SE EJECUTA NADA, y no se publica en /joint_states."""
        req = goal_handle.request
        pedido = Pedido(goal_handle, req.client_id, req.priority, req.joint_positions)
        with self.lock:
            self.pendientes.append(pedido)
            self.por_goal_id[bytes(goal_handle.goal_id.uuid)] = pedido

    def pick_place_goal_callback(self, req):
        pedido_ok = (
            bool(req.client_id.strip())
            and req.accion == 'recoger'
            and req.objeto == 'cubo'
            and req.color in ('rojo', 'azul', 'verde', 'amarillo')
        )
        if self.modo_simulacion:
            modo_ok = True
        else:
            # Físico: solo con pick_place_real, poses completas y lectura real reciente.
            modo_ok = (self.pick_place_real
                       and not pickplace_g3.faltantes(self.poses, req.color, self.usar_vision)
                       and self.posicion_real_reciente()[0]
                       and (self.planificador is None or self.planificador.disponible()))
        valido = pedido_ok and modo_ok
        with self.lock:
            if len(self.pendientes) >= self.cola_max:
                valido = False
            if valido:
                self.n_aceptados += 1
            else:
                self.n_rechazados += 1
        if not valido:
            self.get_logger().warn(
                f'PickPlace rechazado: client={req.client_id} '
                f'accion={req.accion} objeto={req.objeto} color={req.color}. '
                'Revisar: solicitud válida, cola_max, y en modo físico pick_place_real, poses, driver y (si usar_moveit) move_group.'
            )
        return GoalResponse.ACCEPT if valido else GoalResponse.REJECT

    def pick_place_accepted_callback(self, handle):
        req = handle.request
        pedido = Pedido(
            handle, req.client_id, req.priority,
            tipo='pick_place', accion=req.accion,
            objeto=req.objeto, color=req.color,
        )
        with self.lock:
            self.pendientes.append(pedido)
            self.por_goal_id[bytes(handle.goal_id.uuid)] = pedido

    def pick_place_execute_callback(self, handle):
        llave = bytes(handle.goal_id.uuid)
        pedido = self.por_goal_id[llave]
        res = PickPlace.Result()
        if not self.modo_simulacion:
            return self._pick_place_fisico(handle, pedido, llave, res)
        try:
            # Esta fase SOLO simula el tiempo ocupado por un agarre.
            # No llama a MoveIt, al gripper ni publica comandos articulares.
            for _ in range(15):
                if handle.is_cancel_requested:
                    handle.canceled()
                    res.success = False
                    res.message = 'Cancelado durante simulacion'
                    return res
                fb = PickPlace.Feedback()
                fb.state = 'SIMULATING'
                fb.queue_position = 0
                fb.elapsed_s = time.time() - pedido.t_inicio_ejec
                handle.publish_feedback(fb)
                time.sleep(0.2)
            handle.succeed()
            res.success = False  # No hubo agarre físico verificado.
            res.message = 'SIMULADO: desencolado sin movimientos; agarre NO realizado'
            res.position_error_m = float('nan')
            return res
        except Exception as e:
            self.get_logger().error(f'PickPlace falló: {e}')
            handle.abort()
            res.success = False
            res.message = f'Error: {e}'
            return res
        finally:
            res.wait_time_s = pedido.espera_s
            res.exec_time_s = time.time() - pedido.t_inicio_ejec
            with self.lock:
                self.por_goal_id.pop(llave, None)
            pedido.fin.set()

    def _pick_place_fisico(self, handle, pedido, llave, res):
        """Recoger y depositar de verdad. Solo lo corre el worker (un pedido a la vez)."""
        try:
            def feedback(estado):
                fb = PickPlace.Feedback()
                fb.state = estado
                fb.queue_position = 0
                fb.elapsed_s = time.time() - pedido.t_inicio_ejec
                handle.publish_feedback(fb)

            def pinza(valor):
                m = Int32()
                m.data = int(valor)
                self.pub_pinza.publish(m)

            def esperar(q):
                return self.esperar_llegada(q, handle, self.tol_llegada, self.timeout_tramo)

            def ver(pos):
                """Foto desde la pose de mirada; devuelve {color: área_px}."""
                import cv2
                frame = self.cap.leer_frame(self.camara)
                det = self.cap.detectar(frame, 400)
                marca = time.strftime('%H%M%S')
                cv2.imwrite(os.path.join(self.carpeta_capturas, f'pp_{marca}_{pos}.jpg'),
                            self.cap.marcar(frame, det))
                return {c: d['area'] for c, d in det.items()}

            planificar = None
            if self.planificador is not None:
                planificar = lambda qi, qf: self.planificador.planificar(
                    qi, qf, lambda: handle.is_cancel_requested)
            ej = pickplace_g3.EjecutorPickPlace(
                self.poses, self.gripper, self.mover, pinza,
                self.posicion_real_reciente, esperar,
                lambda: handle.is_cancel_requested, feedback,
                tramo_max_rad=self.tramo_max, pausa_pinza_s=self.pausa_pinza,
                log=self.get_logger().info,
                ver=ver if self.usar_vision else None, area_ok_px=self.area_ok,
                objetivos=self.objetivos if self.usar_ik else None,
                ik=self.ik_g3.resolver if self.usar_ik else None,
                planificar=planificar,
                desvio_max=self.desvio_max, ik_desv_max_deg=self.ik_desv_max)
            r = ej.ejecutar(pedido.color)
            self._anotar_tiempos(pedido, r)
            res.success = bool(r['success'])
            res.message = r['message']
            res.position_error_m = float(r['error_pos_m'])
            if handle.is_cancel_requested and not res.success:
                handle.canceled()
            elif res.success:
                handle.succeed()
            else:
                handle.abort()
            return res
        except Exception as e:
            self.get_logger().error(f'PickPlace físico falló: {e}')
            handle.abort()
            res.success = False
            res.message = f'Error: {e}'
            res.position_error_m = float('nan')
            return res
        finally:
            res.wait_time_s = pedido.espera_s
            res.exec_time_s = time.time() - pedido.t_inicio_ejec
            with self.lock:
                self.por_goal_id.pop(llave, None)
            pedido.fin.set()

    def _anotar_tiempos(self, pedido, r):
        """Una fila por pedido físico: sirve para la tabla de P2 y el desglose de tiempos de P3."""
        try:
            t = r.get('tiempos', {})
            fila = {
                't_epoch': round(time.time(), 3), 'cliente': pedido.client_id,
                'color': pedido.color, 'posicion': r.get('posicion') or '',
                'prioridad': pedido.priority, 'espera_cola_s': round(pedido.espera_s, 3),
                'percepcion_s': round(t.get('percepcion_s', 0.0), 3),
                'ik_ms': round(t.get('ik_s', 0.0) * 1000, 1), 'n_ik': t.get('n_ik', 0),
                'plan_moveit_s': round(t.get('plan_s', 0.0), 3), 'n_plan': t.get('n_plan', 0),
                'ejec_total_s': round(time.time() - pedido.t_inicio_ejec, 3),
                'exito_secuencia': bool(r['success']),
                'error_pos_mm': round(r['error_pos_m'] * 1000, 2) if r['error_pos_m'] == r['error_pos_m'] else ''}
            nuevo = not os.path.exists(self.tiempos_csv)
            with open(self.tiempos_csv, 'a', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=list(fila))
                if nuevo:
                    w.writeheader()
                w.writerow(fila)
        except Exception as e:                      # nunca debe tumbar un pedido
            self.get_logger().warn(f'no se pudo anotar tiempos: {e}')

    def _worker(self):
        """El único que decide a quién le toca. Corre en su propio hilo."""
        while not self._parar.is_set():
            pedido = None

            # Bloqueamos la cola solo el instante necesario para sacar un pedido
            with self.lock:
                if not self.ejecutando and self.pendientes:
                    idx = self.politica.siguiente(self.pendientes)
                    if idx is not None:
                        pedido = self.pendientes.pop(idx)

            if pedido is None:
                time.sleep(0.05)
                continue

            if pedido.goal_handle.is_cancel_requested:
                pedido.goal_handle.canceled()
                with self.lock:
                    self.por_goal_id.pop(bytes(pedido.goal_handle.goal_id.uuid), None)
                pedido.fin.set()
                continue

            with self.lock:
                self.ejecutando = pedido
                pedido.t_inicio_ejec = time.time()

            # Esto dispara execute_callback
            pedido.goal_handle.execute()

            # Exclusión mutua: el worker espera hasta que el brazo termine
            pedido.fin.wait()

            with self.lock:
                self.ejecutando = None
                self.n_completados += 1
            self.politica.atendido(pedido)

    def execute_callback(self, goal_handle):
        """Ejecutar UN pedido. Lo llama el worker, nunca handle_accepted."""
        llave = bytes(goal_handle.goal_id.uuid)
        pedido = self.por_goal_id[llave]
        try:
            q_dest = list(goal_handle.request.joint_positions)
            if not self.modo_simulacion:
                reciente, q_ini = self.posicion_real_reciente()
                if not reciente:
                    raise RuntimeError('Sin posición real reciente al desencolar')
                if not fk.dentro_de_limites(q_dest)[0]:
                    raise RuntimeError('Objetivo fuera de límites')
                if not fk.dentro_del_workspace(q_dest)[0]:
                    raise RuntimeError('Objetivo fuera del workspace')
                if fk.paso_articular(q_ini, q_dest) > self.paso_max:
                    raise RuntimeError('Paso excesivo desde la posición real')
            else:
                with self.lock:
                    q_ini = list(self.q_actual)

            pasos = self.pasos
            t_espera = self.duracion / pasos

            # Interpolación: partir el viaje en pasos chiquitos para que sea suave
            for i in range(1, pasos + 1):
                if goal_handle.is_cancel_requested:
                    goal_handle.canceled()
                    return MoveArm.Result()

                q_inter = [q_ini[j] + (q_dest[j] - q_ini[j]) * (i / pasos)
                           for j in range(6)]
                self.mover(q_inter)

                fb = MoveArm.Feedback()
                fb.state = 'EXECUTING'
                fb.queue_position = 0
                fb.elapsed_s = time.time() - pedido.t_inicio_ejec
                goal_handle.publish_feedback(fb)

                time.sleep(t_espera)

            mensaje = 'Movimiento simulado'
            if not self.modo_simulacion:
                confirmado, mensaje = self.esperar_llegada(
                    q_dest, goal_handle
                )
                if not confirmado:
                    if goal_handle.is_cancel_requested:
                        goal_handle.canceled()
                    else:
                        goal_handle.abort()
                    res = MoveArm.Result()
                    res.success = False
                    res.message = mensaje
                    return res

            goal_handle.succeed()
            res = MoveArm.Result()
            res.success = True
            res.message = mensaje
            res.wait_time_s = pedido.espera_s
            res.exec_time_s = time.time() - pedido.t_inicio_ejec
            return res

        except Exception as e:
            self.get_logger().error(f'Fallo ejecutando {pedido}: {e}')
            goal_handle.abort()
            res = MoveArm.Result()
            res.success = False
            res.message = f'Error interno: {e}'
            return res

        finally:
            with self.lock:
                self.por_goal_id.pop(llave, None)
            pedido.fin.set()

    # =========================================================================

    def cancel_callback(self, goal_handle):
        return CancelResponse.ACCEPT

    # ----------------------------------------------------------- publicar
    def recibir_posicion_real(self, msg):
        try:
            posiciones = dict(zip(msg.name, msg.position))
            q = [float(posiciones[n]) for n in fk.JOINT_NAMES]
            if not all(math.isfinite(x) for x in q):
                return
            with self.lock:
                self.q_actual = q
                self.ultima_lectura_real = time.monotonic()
                self.q_real_disponible = True
        except (KeyError, ValueError, TypeError):
            return

    def posicion_real_reciente(self):
        with self.lock:
            reciente = (
                self.q_real_disponible
                and time.monotonic() - self.ultima_lectura_real < 2.0
            )
            return reciente, list(self.q_actual)

    def esperar_llegada(self, destino, goal_handle, tolerancia=None, timeout=8.0):
        limite = time.monotonic() + timeout
        if tolerancia is None:
            tolerancia = math.radians(2.0)
        consecutivas = 0

        while time.monotonic() < limite:
            if goal_handle.is_cancel_requested:
                return False, 'Cancelado; detener el movimiento físicamente si continúa'

            reciente, actual = self.posicion_real_reciente()
            if reciente and max(
                abs(a - b) for a, b in zip(actual, destino)
            ) <= tolerancia:
                consecutivas += 1
                if consecutivas >= 3:
                    return True, 'Llegada confirmada por lectura física'
            else:
                consecutivas = 0

            time.sleep(0.2)

        return False, 'Tiempo agotado esperando llegada física'

    def mover(self, q):
        if self.modo_simulacion:
            self.get_logger().info('[SIMULACION] Movimiento omitido')
            with self.lock:
                self.q_actual = list(q)
            return
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.name = fk.JOINT_NAMES
        msg.position = [float(v) for v in q]
        self.pub_joint.publish(msg)
        # En modo físico q_actual solo se actualiza con la lectura del driver.

    def publicar_estado_cola(self):
        msg = QueueState()
        msg.stamp = self.get_clock().now().to_msg()
        with self.lock:
            ej = self.ejecutando
            msg.executing_client = ej.client_id if ej else ''
            msg.executing_goal_id = ej.goal_id if ej else ''
            msg.executing_elapsed_s = (time.time() - ej.t_inicio_ejec) if ej and ej.t_inicio_ejec else 0.0
            msg.queue_length = len(self.pendientes)
            msg.queued_goal_ids = [p.goal_id for p in self.pendientes]
            msg.queued_clients = [p.client_id for p in self.pendientes]
            msg.queued_priorities = [min(255, max(0, p.priority)) for p in self.pendientes]
            msg.queued_wait_s = [p.espera_s for p in self.pendientes]
            msg.total_accepted = self.n_aceptados
            msg.total_rejected = self.n_rechazados
            msg.total_completed = self.n_completados
            cola = list(self.pendientes)
        self.pub_cola.publish(msg)

        for posicion, p in enumerate(cola, start=1):
            try:
                fb = PickPlace.Feedback() if p.tipo == 'pick_place' else MoveArm.Feedback()
                fb.state = 'QUEUED'
                fb.queue_position = posicion
                fb.elapsed_s = p.espera_s
                p.goal_handle.publish_feedback(fb)
            except Exception:
                pass

    def destroy_node(self):
        self._parar.set()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    nodo = ArmBroker()
    executor = MultiThreadedExecutor()
    executor.add_node(nodo)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
