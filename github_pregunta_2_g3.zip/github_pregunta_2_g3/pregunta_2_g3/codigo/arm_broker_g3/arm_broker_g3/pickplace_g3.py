"""pickplace_g3 — secuencia física de recoger y depositar un cubo (Pregunta 2, grupo 3).

Lógica PURA (sin ROS): el broker le inyecta cómo mover, abrir/cerrar la pinza, leer el
ángulo real y esperar la llegada. Así se puede probar sin brazo.

Cadena del enunciado (modo completo):
    cámara (¿en qué posición está el cubo?) -> objetivo cartesiano conocido de esa posición
    -> CINEMÁTICA INVERSA (ik_g3) -> MOVEIT2 planifica la trayectoria (plan_only)
    -> el worker del broker ejecuta la trayectoria y el gripper agarra / traslada.

Secuencia para el color C (poses de ~/poses_g3.json):
    [con visión] abrir pinza -> ver_<pos> de cada posición hasta ver el color C -> S = esa posición
    abrir pinza -> recoger_S_alto -> recoger_S_bajo -> cerrar pinza -> recoger_S_alto
    -> depositar_C_alto -> depositar_C_bajo -> abrir pinza -> depositar_C_alto -> home
Sin visión (ver=None) se asume que el cubo C está en la posición C.

Cada destino cartesiano (recoger_*/depositar_*) pasa por la IK; home y ver_* son destinos
articulares. Con `planificar` (MoveIt2) la trayectoria viene de MoveIt2; sin él se interpola
en tramos de <= tramo_max_rad (modo anterior). Se espera la llegada física de cada tramo.
Si algo falla se aborta (el brazo se queda donde está).

position_error_m: distancia entre la posición cartesiana SOLICITADA (objetivo) y la FK de
los ángulos leídos del brazo, al llegar a recoger_S_bajo (donde se cierra la pinza).
"""
import json
import math
import os
import time

from arm_broker_g3 import fk

COLORES = ('rojo', 'azul', 'verde', 'amarillo')
ORDEN_ESCANEO = ('azul', 'rojo', 'amarillo', 'verde')


class FalloSecuencia(Exception):
    pass


def cargar_poses(ruta):
    """Devuelve (poses {nombre: grados}, gripper {abierto, cerrado}) o lanza ValueError."""
    ruta = os.path.expanduser(ruta)
    with open(ruta, encoding='utf-8') as f:
        d = json.load(f)
    poses = {n: [float(v) for v in p['grados']] for n, p in d['poses'].items()}
    return poses, d.get('gripper', {'abierto': 100, 'cerrado': 15})


def secuencia(color, slot=None):
    """Pasos de agarre y depósito. slot = posición donde está el cubo (por defecto, la del color)."""
    c, s = color, (slot or color)
    return [
        ('pinza', 'abierto'),
        ('pose', f'recoger_{s}_alto'),
        ('pose', f'recoger_{s}_bajo'),
        ('pinza', 'cerrado'),
        ('pose', f'recoger_{s}_alto'),
        ('pose', f'depositar_{c}_alto'),
        ('pose', f'depositar_{c}_bajo'),
        ('pinza', 'abierto'),
        ('pose', f'depositar_{c}_alto'),
        ('pose', 'home'),
    ]


def poses_necesarias(color, con_vision=False):
    if not con_vision:
        return sorted({n for t, n in secuencia(color) if t == 'pose'})
    n = {f'ver_{p}' for p in ORDEN_ESCANEO}
    for p in ORDEN_ESCANEO:
        n |= {f'recoger_{p}_alto', f'recoger_{p}_bajo'}
    n |= {f'depositar_{color}_alto', f'depositar_{color}_bajo', 'home'}
    return sorted(n)


def faltantes(poses, color, con_vision=False):
    return [n for n in poses_necesarias(color, con_vision) if n not in poses]


def paso(a, b):
    return max(abs(x - y) for x, y in zip(a, b))


def tramos(q_ini, q_dest, max_rad):
    n = max(1, math.ceil(paso(q_ini, q_dest) / max_rad))
    return [[a + (b - a) * i / n for a, b in zip(q_ini, q_dest)] for i in range(1, n + 1)]


def submuestrear(puntos, max_rad):
    """Reduce una trayectoria densa de MoveIt2 [q0, q1, ..., qn] a puntos clave consecutivos
    separados <= max_rad (por articulación). No incluye q0 (el punto de partida) y termina
    SIEMPRE en qn. Si dos puntos seguidos de la trayectoria ya superan max_rad, interpola."""
    if len(puntos) < 2:
        return []
    claves, ultimo, i, n = [], puntos[0], 1, len(puntos)
    while i < n:
        j = i
        while j + 1 < n and paso(ultimo, puntos[j + 1]) <= max_rad:
            j += 1
        if paso(ultimo, puntos[j]) > max_rad:
            claves.extend(tramos(ultimo, puntos[j], max_rad))
        else:
            claves.append(list(puntos[j]))
        ultimo = puntos[j]
        i = j + 1
    return claves


def desvio(puntos):
    """Longitud articular de la trayectoria / distancia directa inicio-fin (1.0 = recta)."""
    largo = sum(math.dist(a, b) for a, b in zip(puntos, puntos[1:]))
    directo = math.dist(puntos[0], puntos[-1])
    return largo / directo if directo > 0.03 else 1.0


def error_posicion_m(q_pedida, q_real):
    a, b = fk.fk(q_pedida), fk.fk(q_real)
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b))) / 1000.0


def error_xyz_m(p_pedida_mm, q_real):
    """Error entre una posición cartesiana pedida (mm) y la FK del RB-2 de los ángulos leídos."""
    b = fk.fk(q_real)
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(p_pedida_mm, b))) / 1000.0


class EjecutorPickPlace:
    def __init__(self, poses, gripper, mover, pinza, leer_q, esperar, cancelado,
                 feedback=None, tramo_max_rad=0.44, pausa_pinza_s=1.5, log=print,
                 ver=None, area_ok_px=8000.0, asentamiento_s=0.8,
                 objetivos=None, ik=None, planificar=None,
                 desvio_max=2.5, ik_desv_max_deg=20.0):
        self.poses, self.gripper = poses, gripper
        self.mover, self.pinza, self.leer_q = mover, pinza, leer_q
        self.esperar, self.cancelado = esperar, cancelado
        self.feedback = feedback or (lambda estado: None)
        self.tramo_max = tramo_max_rad
        self.pausa = pausa_pinza_s
        self.log = log
        self.ver = ver                      # ver(posicion) -> {color: area_px}; None = sin visión
        self.area_ok = area_ok_px
        self.asentamiento = asentamiento_s
        # --- cadena completa
        self.objetivos = objetivos or {}    # {nombre: {'T': 4x4 mm, 'semilla': grados}}
        self.ik = ik                        # ik(T, [semillas rad]) -> dict(ok, q, err_pos_mm, t_ms, mensaje)
        self.planificar = planificar        # planificar(q_ini, q_fin) -> dict(ok, puntos, t_s, mensaje)
        self.desvio_max = desvio_max
        self.ik_desv_max_deg = ik_desv_max_deg
        self.t = {'percepcion_s': 0.0, 'ik_s': 0.0, 'plan_s': 0.0, 'n_ik': 0, 'n_plan': 0}

    # ----------------------------------------------------------- destino (IK o articular)
    def _destino(self, nombre):
        """(q_dest rad, p_pedida mm o None). Si hay objetivo cartesiano, lo calcula la IK."""
        if self.ik is not None and nombre in self.objetivos:
            o = self.objetivos[nombre]
            ref = [math.radians(v) for v in o['semilla']]
            reciente, q_act = self.leer_q()
            r = self.ik(o['T'], [ref] + ([list(q_act)] if reciente else []))
            self.t['ik_s'] += r['t_ms'] / 1000.0
            self.t['n_ik'] += 1
            if not r['ok']:
                raise FalloSecuencia(f'IK sin solución para {nombre}: {r["mensaje"]}')
            dev = math.degrees(paso(r['q'], ref))
            self.log(f'IK {nombre}: {r["t_ms"]:.1f} ms · error {r["err_pos_mm"]:.3f} mm · '
                     f'{dev:.1f}° de la pose enseñada')
            if dev > self.ik_desv_max_deg:
                raise FalloSecuencia(f'IK de {nombre} eligió otra configuración del brazo '
                                     f'({dev:.0f}° de la enseñada): se aborta por seguridad')
            return list(r['q']), [float(v) for v in o['T'][:3, 3]]
        return [math.radians(v) for v in self.poses[nombre]], None

    def _trayectoria(self, nombre, q_ini, q_dest):
        """Puntos clave desde q_ini hasta q_dest (sin q_ini): MoveIt2 si hay, si no interpolación."""
        if self.planificar is None:
            return tramos(q_ini, q_dest, self.tramo_max)
        r = self.planificar(list(q_ini), list(q_dest))
        self.t['plan_s'] += r.get('t_s', 0.0)
        self.t['n_plan'] += 1
        if not r['ok']:
            raise FalloSecuencia(f'MoveIt2 no planificó {nombre}: {r["mensaje"]}')
        puntos = [list(p) for p in r['puntos']]
        if len(puntos) < 2:
            raise FalloSecuencia(f'MoveIt2 devolvió una trayectoria vacía para {nombre}')
        d = desvio(puntos)
        if d > self.desvio_max:
            raise FalloSecuencia(f'trayectoria de MoveIt2 a {nombre} da un rodeo excesivo '
                                 f'({d:.1f}x la ruta directa, máximo {self.desvio_max:.1f}x)')
        for k, q in enumerate(puntos):          # el brazo solo pasa por puntos que el RB-2 admite
            ok, m = fk.dentro_de_limites(q)
            if ok:
                ok, m = fk.dentro_del_workspace(q)
            if not ok:
                raise FalloSecuencia(f'trayectoria a {nombre}: punto {k} rechazado por fk: {m}')
        if paso(puntos[-1], q_dest) > 0.01:
            raise FalloSecuencia(f'la trayectoria a {nombre} no termina en el destino')
        claves = submuestrear([list(q_ini)] + puntos[1:], self.tramo_max)
        if claves:
            claves[-1] = list(q_dest)
        self.log(f'MoveIt2 {nombre}: {r.get("t_s", 0.0):.2f} s · {len(puntos)} puntos '
                 f'-> {len(claves)} tramos · rodeo {d:.2f}x')
        return claves

    def _ir_a(self, nombre):
        q_dest, p_pedida = self._destino(nombre)
        ok, m = fk.dentro_de_limites(q_dest)
        if ok:
            ok, m = fk.dentro_del_workspace(q_dest)
        if not ok:
            raise FalloSecuencia(f'pose {nombre} rechazada por fk: {m}')
        reciente, q_ini = self.leer_q()
        if not reciente:
            raise FalloSecuencia('sin lectura articular reciente')
        for i, q in enumerate(self._trayectoria(nombre, q_ini, q_dest), 1):
            if self.cancelado():
                raise FalloSecuencia('cancelado')
            self.mover(q)
            llego, msg = self.esperar(q)
            if not llego:
                raise FalloSecuencia(f'no llegó a {nombre} (tramo {i}): {msg}')
        reciente, q_fin = self.leer_q()
        return q_dest, (q_fin if reciente else q_dest), p_pedida

    def buscar(self, color, hechos):
        """Visita las posiciones de mirada y devuelve donde está el cubo `color`."""
        vistos = {}
        t0 = time.perf_counter()
        try:
            for pos in ORDEN_ESCANEO:
                if self.cancelado():
                    raise FalloSecuencia('cancelado')
                self.feedback(f'buscar:ver_{pos}')
                self._ir_a(f'ver_{pos}')
                hechos.append(f'ver:{pos}')
                time.sleep(self.asentamiento)
                areas = self.ver(pos) or {}
                vistos[pos] = {c: int(a) for c, a in areas.items()}
                if areas.get(color, 0) >= self.area_ok:
                    return pos, vistos
            raise FalloSecuencia(f'cubo {color} no encontrado en ninguna posición (visto: {vistos})')
        finally:
            self.t['percepcion_s'] += time.perf_counter() - t0

    def resumen_tiempos(self):
        t = self.t
        return (f'percepción {t["percepcion_s"]:.1f} s · IK {t["n_ik"]} cálculos {t["ik_s"] * 1000:.0f} ms · '
                f'MoveIt2 {t["n_plan"]} planes {t["plan_s"]:.2f} s')

    def ejecutar(self, color):
        res = {'success': False, 'message': '', 'error_pos_m': float('nan'), 'hechos': [],
               'posicion': None, 'tiempos': self.t}
        if color not in COLORES:
            res['message'] = f'color {color!r} no soportado'
            return res
        falta = faltantes(self.poses, color, con_vision=self.ver is not None)
        if falta:
            res['message'] = f'faltan poses en poses_g3.json: {falta}'
            return res
        try:
            slot = color
            if self.ver is not None:
                self.pinza(int(self.gripper['abierto']))     # abierta mientras se busca
                time.sleep(self.pausa)
                slot, _ = self.buscar(color, res['hechos'])
                res['posicion'] = slot
                self.log(f'cubo {color} encontrado en la posición {slot}')
            for tipo, nombre in secuencia(color, slot):
                if self.cancelado():
                    raise FalloSecuencia('cancelado')
                self.feedback(f'{tipo}:{nombre}')
                if tipo == 'pinza':
                    self.pinza(int(self.gripper[nombre]))
                    time.sleep(self.pausa)
                else:
                    q_dest, q_real, p_pedida = self._ir_a(nombre)
                    if nombre == f'recoger_{slot}_bajo':
                        res['error_pos_m'] = (error_xyz_m(p_pedida, q_real) if p_pedida is not None
                                              else error_posicion_m(q_dest, q_real))
                res['hechos'].append(f'{tipo}:{nombre}')
            res['success'] = True
            res['message'] = ('Secuencia completa'
                              + (f' (cubo {color} hallado en la posición {slot} por la cámara)'
                                 if self.ver is not None else '')
                              + ('' if self.planificar is None and self.ik is None
                                 else f' · {self.resumen_tiempos()}')
                              + '; el agarre no se verifica con sensor, comprobar a ojo')
        except FalloSecuencia as e:
            res['message'] = (f'ABORTADO tras {len(res["hechos"])} pasos: {e}. '
                              'El brazo se quedó donde estaba; revisar si sostiene un cubo.')
        return res
