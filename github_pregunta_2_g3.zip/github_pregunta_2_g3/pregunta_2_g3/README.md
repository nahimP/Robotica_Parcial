# Pregunta 2 — Grupo 3 (Parcial Gran Reto JetCobot, ESAN Robótica)

Cola de prioridad con broker RB-2, agarre físico con IK propia, MoveIt2 (solo planifica) y cámara.

## Carpetas
- `codigo/arm_broker_g3/` — broker (`broker.py`), política de cola (`politicas.py`), IK propia (`ik_g3.py`), MoveIt2 (`moveit_g3.py`), secuencia de agarre (`pickplace_g3.py`), cinemática directa (`fk.py`).
- `codigo/arm_broker_interfaces_g3/` — acciones `MoveArm` y `PickPlace`, mensaje `QueueState`.
- `codigo/jetcobot_g3/` — driver propio del brazo (`driver_g3.py`, `seguridad_g3.py`, `calibrar_g3.py`).
- `codigo/orq_g3/` — orquestador (cliente de la cola), 10 intentos, monitor de la cola, verificador de publicadores, cámara, poses y `moveit_g3.launch.py`.
- `codigo/config/fastdds_g3.xml` — perfil de red ROS 2 (dominio 92).
- `resultados/` — evidencias generadas (ver `LEEME.txt`).

## Cómo se ejecuta (Jetson)
Cada terminal:
```bash
source /opt/ros/humble/setup.bash; source ~/ros2_ws/install/setup.bash; source ~/rb2_ws/install/setup.bash
export ROS_DOMAIN_ID=92; export FASTRTPS_DEFAULT_PROFILES_FILE=/home/jetson/fastdds_g3.xml
```
1. Driver: `ros2 run jetcobot_g3 driver_g3 --ros-args -p dry_run:=false`
2. MoveIt2 (solo planifica): `ros2 launch ~/orq_g3/moveit_g3.launch.py`
3. Broker: `ros2 run arm_broker_g3 broker --ros-args -p politica:=prioridad -p modo_simulacion:=false -p pick_place_real:=true -p usar_vision:=true -p usar_ik:=true -p usar_moveit:=true`
4. Intérprete de órdenes (Pregunta 1) y LAYA en la PC del laboratorio.
5. `python3 orquestador_g3.py --paralelo "ana:recoge el cubo rojo con urgencia" "luis:es importante que recojas el cubo azul"`
   · `python3 intentos_g3.py` · `python3 monitor_cola_g3.py`

`tau_envejecimiento_s` fue 8 s (valor por defecto) en los diez intentos; ver el informe.
El broker es el único nodo que publica en `/arm_g3/joint_command`.
